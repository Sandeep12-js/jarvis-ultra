package com.sandeep.jarvis

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Glowing energy sphere with tilted orbit rings, orbiting lights, a hologram base and particles.
 * Its movement and colour change with the assistant state.
 */
class OrbView(context: Context) : View(context) {

    var state: AssistantState = AssistantState.READY
        set(value) {
            field = value
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()
    private val rnd = Random(21)
    private val pCount = 26
    private val pAngle = FloatArray(pCount) { rnd.nextFloat() * 6.2831855f }
    private val pRadius = FloatArray(pCount) { 0.58f + rnd.nextFloat() * 0.40f }
    private val pSize = FloatArray(pCount) { 1.0f + rnd.nextFloat() * 2.2f }
    private val pSpeed = FloatArray(pCount) {
        (0.15f + rnd.nextFloat() * 0.7f) * (if (rnd.nextBoolean()) 1f else -1f)
    }
    private val tilts = floatArrayOf(-28f, 32f, 88f)

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    private fun a(color: Int, alpha: Int): Int =
        (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f - min(width, height) * 0.03f
        val base = min(width, height) / 2f
        val d = resources.displayMetrics.density
        val sec = (SystemClock.uptimeMillis() % 3_600_000L) / 1000f
        val c = state.color

        val amp: Float
        val speed: Float
        val energy: Float
        when (state) {
            AssistantState.READY -> { amp = 0.025f; speed = 1.0f; energy = 0.4f }
            AssistantState.LISTENING -> { amp = 0.05f; speed = 2.2f; energy = 1.0f }
            AssistantState.THINKING -> { amp = 0.035f; speed = 5.0f; energy = 0.8f }
            AssistantState.SPEAKING -> { amp = 0.07f; speed = 3.0f; energy = 1.2f }
            AssistantState.STANDBY -> { amp = 0.015f; speed = 0.5f; energy = 0.2f }
            AssistantState.MUTED -> { amp = 0.012f; speed = 0.3f; energy = 0.1f }
            AssistantState.OFFLINE -> { amp = 0f; speed = 0f; energy = 0f }
            AssistantState.ERROR -> { amp = 0.04f; speed = 7.0f; energy = 0.8f }
            AssistantState.SHARING -> { amp = 0.03f; speed = 1.8f; energy = 0.6f }
        }
        val dim = if (state == AssistantState.OFFLINE) 0.25f else 1f
        var breath = 1f + amp * sin(sec * 3.1415927f * speed)
        if (state == AssistantState.SPEAKING) breath += amp * 0.5f * sin(sec * 12f)
        val r = base * 0.50f * breath

        // 1. Soft glow behind everything
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx, cy, base,
            intArrayOf(a(c, (95 * dim).toInt()), a(c, (32 * dim).toInt()), a(c, 0)),
            floatArrayOf(0.25f, 0.65f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, base, paint)
        paint.shader = null

        // 2. Hologram base under the sphere
        val by = cy + base * 0.88f
        paint.shader = RadialGradient(
            cx, by, base * 0.85f,
            intArrayOf(a(c, (90 * dim).toInt()), a(c, 0)), null, Shader.TileMode.CLAMP
        )
        canvas.save()
        canvas.scale(1f, 0.22f, cx, by)
        canvas.drawCircle(cx, by, base * 0.85f, paint)
        canvas.restore()
        paint.shader = null
        for (i in 0..1) {
            val s = if (i == 0) 1f else 0.7f
            rect.set(cx - base * 0.78f * s, by - base * 0.11f * s, cx + base * 0.78f * s, by + base * 0.11f * s)
            ring.strokeWidth = d * 1.4f
            ring.color = a(c, ((120 - i * 45) * dim).toInt())
            canvas.drawOval(rect, ring)
        }

        // 3. The sphere
        paint.shader = RadialGradient(
            cx - r * 0.30f, cy - r * 0.34f, r * 1.45f,
            intArrayOf(
                a(Color.WHITE, (235 * dim).toInt()),
                a(c, (235 * dim).toInt()),
                a(Palette.BLUE, (215 * dim).toInt()),
                a(0xFF0A1E5C.toInt(), (255 * dim).toInt())
            ),
            floatArrayOf(0f, 0.28f, 0.66f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, paint)
        paint.shader = null

        // 4. Globe wireframe (rotating)
        ring.strokeWidth = d * 0.8f
        ring.color = a(Color.WHITE, (55 * dim).toInt())
        for (k in -2..2) {
            val yy = r * k * 0.33f
            val half = sqrt(max(0f, r * r - yy * yy))
            val h = half * 0.20f
            rect.set(cx - half, cy + yy - h, cx + half, cy + yy + h)
            canvas.drawOval(rect, ring)
        }
        val ph = sec * speed * 0.25f
        for (k in 0 until 4) {
            val w = r * abs(cos(ph + k * 0.7854f))
            rect.set(cx - w, cy - r, cx + w, cy + r)
            canvas.drawOval(rect, ring)
        }
        // bright rim
        ring.strokeWidth = d * 1.6f
        ring.color = a(c, (150 * dim).toInt())
        canvas.drawCircle(cx, cy, r, ring)

        // 5. Pulse ring (listening / speaking / thinking)
        if (energy >= 0.7f) {
            val t = (sec * (0.6f + 0.25f * speed)) % 1f
            val pr = r * (1.08f + 0.62f * t)
            ring.strokeWidth = d * 2f
            ring.color = a(c, (150 * (1f - t) * dim).toInt())
            canvas.drawCircle(cx, cy, pr, ring)
        }

        // 6. Orbit rings with travelling lights
        val oa = base * 0.93f
        val ob = base * 0.29f
        for (k in 0..2) {
            canvas.save()
            canvas.rotate(tilts[k] + sec * (2.5f + speed * 2f) * (if (k % 2 == 0) 1f else -1f), cx, cy)
            ring.strokeWidth = d * 1.2f
            ring.color = a(if (k == 1) Palette.PURPLE else c, (165 * dim).toInt())
            rect.set(cx - oa, cy - ob, cx + oa, cy + ob)
            canvas.drawOval(rect, ring)
            for (j in 0..1) {
                val t = sec * (0.6f + 0.25f * speed) * (1f + k * 0.3f) + j * 3.14159f + k
                val px = cx + oa * cos(t)
                val py = cy + ob * sin(t)
                paint.color = a(c, (80 * dim).toInt())
                canvas.drawCircle(px, py, d * 6f, paint)
                paint.color = a(Color.WHITE, (255 * dim).toInt())
                canvas.drawCircle(px, py, d * 2.4f, paint)
            }
            canvas.restore()
        }

        // 7. Particles
        for (i in 0 until pCount) {
            val ang = pAngle[i] + sec * pSpeed[i] * (0.25f + 0.25f * speed)
            val rad = base * pRadius[i]
            val tw = 0.5f + 0.5f * sin(sec * 2f + i)
            paint.color = a(if (i % 4 == 0) Palette.PURPLE else c, ((40 + 170 * tw) * dim).toInt())
            canvas.drawCircle(cx + cos(ang) * rad, cy + sin(ang) * rad * 0.9f, pSize[i] * d * 0.6f, paint)
        }
    }
}
