package com.sandeep.jarvis

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Speech-to-text (Android SpeechRecognizer) + text-to-speech (Android TextToSpeech).
 * Everything here must be called from the main thread.
 * Long replies are spoken sentence by sentence so speech starts quickly.
 */
class VoiceEngine(
    private val ctx: Context,
    private val prefs: Prefs,
    private val listener: Listener
) {
    interface Listener {
        fun onHeard(text: String)
        fun onListeningStarted()
        fun onVoiceError(message: String, fatal: Boolean)
        fun onSpeakStart()
        fun onSpeakDone()
    }

    private val handler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    private var wantListening = false
    private var active = false
    private var speaking = false
    private var currentBase: String? = null
    private var lastId: String? = null
    private var startNotified = false
    private var consecutiveErrors = 0

    private val restart = Runnable { beginRecognition() }

    // ---------- Text to speech ----------

    fun init(onReady: () -> Unit) {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        handler.post {
                            val b = currentBase
                            if (b != null && utteranceId != null && utteranceId.startsWith(b) && !startNotified) {
                                startNotified = true
                                listener.onSpeakStart()
                            }
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        handler.post {
                            if (utteranceId != null && utteranceId == lastId) {
                                speaking = false
                                currentBase = null
                                lastId = null
                                listener.onSpeakDone()
                            }
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        handler.post {
                            val b = currentBase
                            if (b != null && utteranceId != null && utteranceId.startsWith(b)) {
                                speaking = false
                                currentBase = null
                                lastId = null
                                listener.onVoiceError("Voice output failed.", false)
                                listener.onSpeakDone()
                            }
                        }
                    }
                })
                refreshVoice()
            } else {
                listener.onVoiceError(
                    "No text-to-speech engine found. JARVIS can show text but cannot speak.", false
                )
            }
            onReady()
        }
    }

    /** Re-apply language/voice from settings. */
    fun refreshVoice() {
        val engine = tts ?: return
        if (!ttsReady) return
        val loc = Locale.forLanguageTag(prefs.language)
        val r = engine.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.US) // some engines only ship US English; the voice still works
        }
        try {
            VoiceNames.pick(engine.voices, prefs.voiceName)?.let { engine.voice = it }
        } catch (e: Exception) {
            // keep default voice
        }
        engine.setPitch(0.85f)       // slightly deeper
        engine.setSpeechRate(0.95f)
    }

    private fun splitForSpeech(text: String): List<String> {
        val sentences = text.trim().split(Regex("(?<=[.!?\\u0964])\\s+")).filter { it.isNotBlank() }
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (s in sentences) {
            val limit = if (out.isEmpty()) 90 else 220
            if (sb.isNotEmpty() && sb.length + s.length > limit) {
                out.add(sb.toString())
                sb.setLength(0)
            }
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(s)
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out.map { if (it.length > 3500) it.take(3500) else it }
    }

    fun speak(text: String) {
        pauseRecognition()
        val engine = tts
        val parts = splitForSpeech(text)
        if (engine == null || !ttsReady || parts.isEmpty()) {
            speaking = false
            handler.post { listener.onSpeakDone() }
            return
        }
        val base = "jarvis-" + System.nanoTime()
        currentBase = base
        lastId = "$base-${parts.size - 1}"
        startNotified = false
        speaking = true
        for ((i, p) in parts.withIndex()) {
            engine.speak(
                p,
                if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                null,
                "$base-$i"
            )
        }
    }

    fun stopSpeaking() {
        currentBase = null
        lastId = null
        speaking = false
        tts?.stop()
    }

    // ---------- Speech recognition ----------

    fun startListening() {
        wantListening = true
        if (!speaking && !active) handler.post(restart)
    }

    fun stopListening() {
        wantListening = false
        pauseRecognition()
    }

    private fun pauseRecognition() {
        handler.removeCallbacks(restart)
        active = false
        try {
            recognizer?.cancel()
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        handler.removeCallbacks(restart)
        if (wantListening && !speaking) handler.postDelayed(restart, delayMs)
    }

    private fun beginRecognition() {
        if (!wantListening || speaking || active) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            wantListening = false
            listener.onVoiceError(
                "Speech recognition is not available on this phone. Install or enable Google speech services.",
                true
            )
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).also {
                it.setRecognitionListener(recListener)
            }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        active = true
        try {
            recognizer?.startListening(intent)
            listener.onListeningStarted()
        } catch (e: Exception) {
            active = false
            listener.onVoiceError("Could not start listening: ${e.message}", true)
        }
    }

    private val recListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onResults(results: Bundle?) {
            active = false
            consecutiveErrors = 0
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
            if (text.isNullOrEmpty()) {
                scheduleRestart(300)
            } else {
                // Activity will speak a reply (which restarts listening afterwards).
                listener.onHeard(text)
            }
        }

        override fun onError(error: Int) {
            active = false
            if (!wantListening || speaking) return
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    wantListening = false
                    listener.onVoiceError("Microphone permission is missing.", true)
                }
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> scheduleRestart(300)
                SpeechRecognizer.ERROR_CLIENT -> { /* caused by cancel(); ignore */ }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    try { recognizer?.destroy() } catch (e: Exception) { }
                    recognizer = null
                    scheduleRestart(800)
                }
                else -> {
                    consecutiveErrors++
                    if (consecutiveErrors >= 3) {
                        wantListening = false
                        listener.onVoiceError(
                            "Speech recognition keeps failing (code $error). Check your internet connection and Google speech services, then tap the mic.",
                            true
                        )
                    } else {
                        scheduleRestart(1500)
                    }
                }
            }
        }
    }

    fun destroy() {
        wantListening = false
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (e: Exception) { }
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
