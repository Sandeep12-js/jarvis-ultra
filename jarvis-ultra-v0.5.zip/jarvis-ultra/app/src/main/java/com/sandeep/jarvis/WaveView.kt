package com.sandeep.jarvis

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.SystemClock
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.sin

/** Small animated voice bars. Height follows the assistant state. */
class WaveView(context: Context) : View(context) {

    var state: AssistantState = AssistantState.READY
        set(value) {
            field = value
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density
        val sec = (SystemClock.uptimeMillis() % 3_600_000L) / 1000f
        val energy = when (state) {
            AssistantState.LISTENING -> 1.0f
            AssistantState.SPEAKING -> 1.0f
            AssistantState.THINKING -> 0.6f
            AssistantState.SHARING -> 0.5f
            AssistantState.READY -> 0.25f
            AssistantState.ERROR -> 0.5f
            else -> 0.1f
        }
        paint.strokeWidth = 3f * d
        paint.color = (state.color and 0x00FFFFFF) or (0xDD shl 24)
        val bars = 7
        for (i in 0 until bars) {
            val x = w * (i + 0.5f) / bars
            val amp = (0.25f + 0.75f * abs(sin(sec * (4f + i) + i * 1.3f))) * energy
            val half = h * 0.5f * amp.coerceIn(0.1f, 1f)
            canvas.drawLine(x, h / 2f - half, x, h / 2f + half, paint)
        }
    }
}
