package com.sandeep.jarvis

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Locale

class SettingsActivity : AppCompatActivity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: Prefs
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private val languages = listOf(
        "English (India)" to "en-IN",
        "English (US)" to "en-US",
        "Hindi" to "hi-IN",
        "Punjabi" to "pa-IN"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = Prefs(this)
        tts = TextToSpeech(this) { ttsReady = (it == TextToSpeech.SUCCESS) }
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(TextView(this).apply {
            text = "\u2190"
            textSize = 26f
            setTextColor(Palette.CYAN)
            gravity = Gravity.CENTER
            contentDescription = "Back"
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(56), dp(56)))
        bar.addView(TextView(this).apply {
            text = "SETTINGS"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
            setTextColor(Palette.CYAN)
        })
        root.addView(bar, LinearLayout.LayoutParams(MATCH, dp(56)))

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }

        // 1
        val n = AiStore(this).usableCount()
        list.addView(card("1. AI & Intelligence Settings",
            if (n > 0) "WORKING: $n provider(s) enabled" else "NOT CONNECTED: no provider enabled",
            if (n > 0) Palette.GREEN else Palette.ORANGE,
            "Add your own key for Google Gemini (free tier), OpenRouter, Groq, DeepSeek or any OpenAI-compatible server. " +
                "Keys are stored encrypted on this phone. Nothing paid is used unless you enable it.",
            action("Open AI settings") { startActivity(Intent(this, AiSettingsActivity::class.java)) }))

        // 2
        val langName = languages.firstOrNull { it.second == prefs.language }?.first ?: prefs.language
        list.addView(card("2. Voice & Language", "WORKING", Palette.GREEN,
            "Language: $langName\nVoice: ${prefs.voiceName?.let { VoiceNames.friendly(it) } ?: "Auto (British male if your phone has one)"}\n\n" +
                "JARVIS can only use voices installed in your phone's text-to-speech engine. " +
                "The voice am_onyx is not in your phone's current voice pack.",
            action("Choose language") { pickLanguage() },
            action("Choose voice") { pickVoice() },
            action("Test voice") { testVoice() }))

        // 3
        list.addView(card("3. Modes & Behavior", "PARTIAL", Palette.ORANGE,
            "Current mode: ${AssistantMode.fromName(prefs.mode).label}\n" +
                "Switch modes from the side panel (\u2630) or by saying \"switch to pro mode\". " +
                "Each mode gives the AI a different personality and style."))

        // 4
        list.addView(card("4. Memory & Personalization", "NOT IMPLEMENTED (Phase E)", Palette.GREY,
            "No memory is stored. Nothing about you is saved except language, voice and mode."))

        // 5
        list.addView(card("5. Camera & Screen Sharing", "WORKING (needs an AI key with image support)", Palette.GREEN,
            "Camera: tap CAMERA to open the live camera inside JARVIS. Show something and ask by voice, " +
                "or tap the picture. JARVIS looks at the current frame when you ask (it is not continuous video).\n\n" +
                "Screen: tap SCREEN and approve Android's permission. JARVIS then listens in the background while you use other apps; " +
                "ask about your screen and it answers by voice. A notification stays visible with a STOP button. " +
                "Nothing is captured unless you approve, and STOP ends it.\n\n" +
                "Image questions work with Google Gemini and with Groq's vision model."))

        // 6
        list.addView(card("6. Automation & Tools", "PARTIAL", Palette.ORANGE,
            "Working by voice: open YouTube, Instagram or the browser, search the web in your browser, tell the time and date, " +
                "open the camera, start screen sharing.\n" +
                "Not built: accessibility control (tap, swipe, type), notes, reminders, files, floating bubble, wake word."))

        // 7
        val mic = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        list.addView(card("7. Privacy & Security", "PARTIAL", Palette.ORANGE,
            "Microphone permission: ${if (mic) "GRANTED" else "NOT GRANTED"}\n" +
                "JARVIS listens only while this app is open and the mic is not muted, or while screen sharing is ON (shown by a notification). " +
                "There is no wake word yet.\n" +
                "Camera and screen are used only after you tap their buttons and approve Android's permission.\n" +
                "Network: only secure (HTTPS) connections are allowed.",
            action("Open app permissions") {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }))

        // 8
        list.addView(card("8. System & Backup", "NOT IMPLEMENTED (Phase E/G)", Palette.GREY,
            "Backup, restore and diagnostics are not built yet."))

        // 9
        list.addView(card("9. Update Center", "NOT IMPLEMENTED", Palette.GREY,
            "To update, install a newer APK built by your GitHub Actions workflow over this one."))

        // 10
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        list.addView(card("10. About JARVIS", "", Palette.CYAN,
            "Application: JARVIS-ULTRA\nDeveloper: Sandeep Sir\n\nVersion $ver (early build)"))

        val scroll = ScrollView(this)
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val frame = android.widget.FrameLayout(this).apply { setBackgroundColor(Palette.BG) }
        frame.addView(HudBackground(this), ViewGroup.LayoutParams(MATCH, MATCH))
        frame.addView(root, ViewGroup.LayoutParams(MATCH, MATCH))
        setContentView(frame)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
    }

    private fun card(title: String, status: String, statusColor: Int, body: String, vararg extra: View): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(0xFF0D1626.toInt())
                setStroke(dp(1), 0x3300E5FF)
            }
        }
        c.addView(TextView(this).apply {
            text = title
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Palette.CYAN)
        })
        if (status.isNotEmpty()) {
            c.addView(TextView(this).apply {
                text = status
                textSize = 10.5f
                typeface = Typeface.DEFAULT_BOLD
                letterSpacing = 0.08f
                setTextColor(statusColor)
                setPadding(dp(10), dp(3), dp(10), dp(3))
                background = GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat()
                    setColor((statusColor and 0x00FFFFFF) or 0x22000000)
                    setStroke(dp(1), statusColor)
                }
                layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply {
                    topMargin = dp(4)
                    bottomMargin = dp(8)
                }
            })
        }
        c.addView(TextView(this).apply {
            text = body
            textSize = 14f
            setTextColor(Palette.TEXT)
        })
        for (v in extra) c.addView(v)
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(12)
        c.layoutParams = lp
        return c
    }

    private fun action(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Palette.CYAN)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), Palette.CYAN)
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) }
    }

    private fun pickLanguage() {
        AlertDialog.Builder(this)
            .setTitle("Language")
            .setItems(languages.map { it.first }.toTypedArray()) { _, i ->
                prefs.language = languages[i].second
                prefs.voiceName = null
                build()
            }.show()
    }

    private fun pickVoice() {
        val engine = tts
        if (engine == null || !ttsReady) {
            Toast.makeText(this, "Voice engine is not ready.", Toast.LENGTH_SHORT).show()
            return
        }
        val loc = Locale.forLanguageTag(prefs.language)
        val voices = try {
            val all = engine.voices?.toList() ?: emptyList()
            val sameLang = all.filter { it.locale.language == loc.language }
            (if (sameLang.isNotEmpty()) sameLang else all).sortedBy { it.name }
        } catch (e: Exception) {
            emptyList()
        }
        if (voices.isEmpty()) {
            Toast.makeText(
                this,
                "No installed voices for this language. Install voice data in Android Settings > Text-to-speech.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Voice")
            .setItems(voices.map { VoiceNames.friendly(it.name) }.toTypedArray()) { _, i ->
                prefs.voiceName = voices[i].name
                build()
                testVoice()
            }.show()
    }

    private fun testVoice() {
        val engine = tts
        if (engine == null || !ttsReady) {
            Toast.makeText(this, "Voice engine is not ready.", Toast.LENGTH_SHORT).show()
            return
        }
        val lr = engine.setLanguage(Locale.forLanguageTag(prefs.language))
        if (lr == TextToSpeech.LANG_MISSING_DATA || lr == TextToSpeech.LANG_NOT_SUPPORTED) engine.setLanguage(Locale.US)
        try {
            VoiceNames.pick(engine.voices, prefs.voiceName)?.let { engine.voice = it }
        } catch (e: Exception) { }
        engine.setPitch(0.85f)
        engine.setSpeechRate(0.95f)
        engine.speak(Greetings.FIRST, TextToSpeech.QUEUE_FLUSH, null, "test")
    }
}
