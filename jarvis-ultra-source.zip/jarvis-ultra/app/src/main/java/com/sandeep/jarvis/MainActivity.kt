package com.sandeep.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.drawerlayout.widget.DrawerLayout

class MainActivity : AppCompatActivity(), VoiceEngine.Listener, CommandRouter.Host {

    private class Control(val root: LinearLayout, val frame: FrameLayout, val icon: ImageView)

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: Prefs
    private lateinit var voice: VoiceEngine
    private lateinit var orb: OrbView
    private lateinit var statusView: TextView
    private lateinit var orbLabel: TextView
    private lateinit var hintView: TextView
    private lateinit var modeView: TextView
    private lateinit var drawer: DrawerLayout
    private lateinit var micControl: Control
    private lateinit var powerControl: Control
    private lateinit var micLed: View
    private val modeRows = LinkedHashMap<AssistantMode, TextView>()

    private var powerOn = true
    private var muted = false
    private var resumed = false
    private var voiceReady = false
    private var busy = AssistantState.READY
    private var errorMessage: String? = null
    private var hint: String? = null
    private var pendingAfter: (() -> Unit)? = null

    override val currentMode: AssistantMode
        get() = AssistantMode.fromName(prefs.mode)

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                errorMessage = null
                hint = null
                startListeningIfAllowed()
            } else {
                hint = "Microphone permission denied. Enable it in phone Settings > Apps > JARVIS-ULTRA > Permissions."
            }
            updateUi()
        }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = Prefs(this)
        buildUi()
        voice = VoiceEngine(this, prefs, this)
        updateUi()
        voice.init { onVoiceReady() }
    }

    private fun onVoiceReady() {
        voiceReady = true
        if (!micGranted()) {
            hint = "JARVIS needs the microphone to hear you. Please allow it."
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
        if (powerOn) {
            if (!prefs.greeted) {
                prefs.greeted = true
                speakThen(Greetings.FIRST, null)
            } else {
                startListeningIfAllowed()
            }
        }
        updateUi()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        if (voiceReady) {
            voice.refreshVoice()
            startListeningIfAllowed()
        }
        updateUi()
    }

    override fun onPause() {
        resumed = false
        pendingAfter = null
        if (voiceReady) {
            voice.stopListening()
            voice.stopSpeaking()
        }
        if (busy == AssistantState.SPEAKING || busy == AssistantState.THINKING ||
            busy == AssistantState.LISTENING
        ) busy = AssistantState.READY
        super.onPause()
    }

    override fun onDestroy() {
        voice.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------ UI building

    private fun buildUi() {
        drawer = DrawerLayout(this)
        val content = FrameLayout(this).apply { setBackgroundColor(Palette.BG) }
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        content.addView(main, FrameLayout.LayoutParams(MATCH, MATCH))

        // Header: menu (left) | JARVIS-ULTRA (center) | gear (right)
        val header = FrameLayout(this)
        val menu = TextView(this).apply {
            text = "\u2630"
            textSize = 24f
            setTextColor(Palette.CYAN)
            gravity = Gravity.CENTER
            contentDescription = "Assistant modes"
            setOnClickListener { drawer.openDrawer(GravityCompat.START) }
        }
        val title = TextView(this).apply {
            text = "JARVIS-ULTRA"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
            setTextColor(Palette.CYAN)
            gravity = Gravity.CENTER
            setShadowLayer(18f, 0f, 0f, Palette.CYAN)
        }
        val gear = TextView(this).apply {
            text = "\u2699"
            textSize = 24f
            setTextColor(Palette.SUBTEXT)
            gravity = Gravity.CENTER
            contentDescription = "Settings"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        header.addView(menu, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.START or Gravity.CENTER_VERTICAL))
        header.addView(title, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        header.addView(gear, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END or Gravity.CENTER_VERTICAL))
        main.addView(header, LinearLayout.LayoutParams(MATCH, dp(64)))

        statusView = TextView(this).apply {
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.15f
            gravity = Gravity.CENTER
        }
        main.addView(statusView, LinearLayout.LayoutParams(MATCH, WRAP))

        modeView = TextView(this).apply {
            textSize = 12f
            setTextColor(Palette.SUBTEXT)
            letterSpacing = 0.1f
            gravity = Gravity.CENTER
        }
        main.addView(modeView, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })

        main.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        orb = OrbView(this)
        main.addView(orb, LinearLayout.LayoutParams(dp(240), dp(240)))

        orbLabel = TextView(this).apply {
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.2f
            gravity = Gravity.CENTER
        }
        main.addView(orbLabel, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        hintView = TextView(this).apply {
            textSize = 13f
            setTextColor(Palette.SUBTEXT)
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(8), dp(24), 0)
            minLines = 3
            maxLines = 6
        }
        main.addView(hintView, LinearLayout.LayoutParams(MATCH, WRAP))

        main.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        // Exactly four bottom controls
        val camera = control(R.drawable.ic_camera, "CAMERA", Palette.CYAN) {
            Toast.makeText(this, "Camera vision is not built yet (Phase D).", Toast.LENGTH_LONG).show()
        }
        val screen = control(R.drawable.ic_screen, "SCREEN", Palette.BLUE) {
            Toast.makeText(this, "Screen sharing is not built yet (Phase D).", Toast.LENGTH_LONG).show()
        }
        micControl = control(R.drawable.ic_mic, "MIC", Palette.CYAN) { onMicTapped() }
        powerControl = control(R.drawable.ic_power, "POWER", Palette.GREEN) { onPowerTapped() }

        micLed = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Palette.YELLOW) }
        }
        micControl.frame.addView(
            micLed,
            FrameLayout.LayoutParams(dp(14), dp(14), Gravity.TOP or Gravity.END)
        )

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), 0)
        }
        for (c in listOf(camera, screen, micControl, powerControl)) {
            row.addView(c.root, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        main.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))

        // Side panel with the four modes, in order
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Palette.PANEL)
            setPadding(dp(16), dp(64), dp(16), dp(16))
        }
        panel.addView(TextView(this).apply {
            text = "ASSISTANT MODES"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.15f
            setTextColor(Palette.CYAN)
            setPadding(0, 0, 0, dp(16))
        })
        for (m in AssistantMode.values()) {
            val rowView = TextView(this).apply {
                text = m.label + "\n" + m.blurb
                textSize = 15f
                setTextColor(Palette.TEXT)
                setPadding(dp(14), dp(14), dp(14), dp(14))
                setOnClickListener {
                    drawer.closeDrawer(GravityCompat.START)
                    switchMode(m)
                    speakThen("${m.label} selected, Sir.", null)
                }
            }
            modeRows[m] = rowView
            panel.addView(rowView, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) })
        }

        drawer.addView(content, DrawerLayout.LayoutParams(MATCH, MATCH))
        drawer.addView(panel, DrawerLayout.LayoutParams(dp(270), MATCH, Gravity.START))
        setContentView(drawer)

        ViewCompat.setOnApplyWindowInsetsListener(main) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom + dp(16))
            insets
        }
    }

    private fun control(iconRes: Int, caption: String, accent: Int, onClick: () -> Unit): Control {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val frame = FrameLayout(this)
        val icon = ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(accent)
            setPadding(dp(18), dp(18), dp(18), dp(18))
            contentDescription = caption
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x1A00E5FF)
                setStroke(dp(2), accent)
            }
            setOnClickListener { onClick() }
        }
        frame.addView(icon, FrameLayout.LayoutParams(dp(68), dp(68), Gravity.CENTER))
        col.addView(frame, LinearLayout.LayoutParams(dp(76), dp(76)))
        col.addView(TextView(this).apply {
            text = caption
            textSize = 11f
            letterSpacing = 0.12f
            setTextColor(Palette.SUBTEXT)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })
        return Control(col, frame, icon)
    }

    // ------------------------------------------------------------ state / UI refresh

    private fun micGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun effectiveState(): AssistantState = when {
        !powerOn -> AssistantState.OFFLINE
        errorMessage != null -> AssistantState.ERROR
        busy == AssistantState.SPEAKING || busy == AssistantState.THINKING -> busy
        muted -> AssistantState.MUTED
        !micGranted() -> AssistantState.STANDBY
        else -> busy
    }

    private fun updateUi() {
        val st = effectiveState()
        orb.state = st
        statusView.text = "\u25CF " + st.status
        statusView.setTextColor(st.color)
        orbLabel.text = st.orbLabel
        orbLabel.setTextColor(st.color)
        hintView.text = errorMessage ?: hint ?: ""
        hintView.setTextColor(if (errorMessage != null) Palette.ORANGE else Palette.SUBTEXT)
        modeView.text = "MODE: " + currentMode.label

        val led = when {
            !powerOn -> Palette.GREY
            muted -> Palette.RED
            st == AssistantState.LISTENING -> Palette.GREEN
            else -> Palette.YELLOW
        }
        (micLed.background as GradientDrawable).setColor(led)
        micControl.icon.setColorFilter(if (muted) Palette.RED else Palette.CYAN)
        powerControl.icon.setColorFilter(if (powerOn) Palette.GREEN else Palette.GREY)

        for ((m, v) in modeRows) {
            val sel = m == currentMode
            v.background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(if (sel) 0x3300E5FF else 0x11FFFFFF)
                setStroke(dp(1), if (sel) Palette.CYAN else 0x22FFFFFF)
            }
        }
    }

    // ------------------------------------------------------------ user actions

    private fun onMicTapped() {
        if (!powerOn) {
            hint = "JARVIS is powered off. Tap the power button first."
            updateUi()
            return
        }
        if (errorMessage != null) {            // retry after a failure
            errorMessage = null
            hint = null
            if (!micGranted()) micPermission.launch(Manifest.permission.RECORD_AUDIO)
            else startListeningIfAllowed()
            updateUi()
            return
        }
        muted = !muted
        if (muted) {
            voice.stopListening()
            hint = "Microphone muted. JARVIS cannot hear you."
        } else {
            hint = null
            if (!micGranted()) micPermission.launch(Manifest.permission.RECORD_AUDIO)
            else startListeningIfAllowed()
        }
        updateUi()
    }

    private fun onPowerTapped() {
        if (powerOn) powerOff() else powerOnNow()
    }

    private fun powerOnNow() {
        powerOn = true
        errorMessage = null
        hint = null
        speakThen(Greetings.POWER_ON, null)
        updateUi()
    }

    private fun startListeningIfAllowed() {
        if (!resumed || !voiceReady || !powerOn || muted || errorMessage != null) return
        if (!micGranted()) return
        voice.startListening()
    }

    private fun speakThen(text: String, after: (() -> Unit)?) {
        pendingAfter = after
        hint = (hint?.takeIf { it.startsWith("You:") }?.plus("\n") ?: "") + "JARVIS: " + text
        busy = AssistantState.THINKING
        updateUi()
        voice.speak(text)
    }

    // ------------------------------------------------------------ VoiceEngine.Listener

    override fun onHeard(text: String) {
        busy = AssistantState.THINKING
        hint = "You: $text"
        updateUi()
        val reply = CommandRouter.handle(text, this)
        speakThen(reply.text, reply.after)
    }

    override fun onListeningStarted() {
        if (busy != AssistantState.SPEAKING && busy != AssistantState.THINKING) {
            busy = AssistantState.LISTENING
            updateUi()
        }
    }

    override fun onVoiceError(message: String, fatal: Boolean) {
        if (fatal) errorMessage = message else hint = message
        updateUi()
    }

    override fun onSpeakStart() {
        busy = AssistantState.SPEAKING
        updateUi()
    }

    override fun onSpeakDone() {
        busy = AssistantState.READY
        val after = pendingAfter
        pendingAfter = null
        after?.invoke()
        startListeningIfAllowed()
        updateUi()
    }

    // ------------------------------------------------------------ CommandRouter.Host

    override fun switchMode(mode: AssistantMode) {
        prefs.mode = mode.name
        updateUi()
    }

    override fun muteMic() {
        muted = true
        voice.stopListening()
        updateUi()
    }

    override fun powerOff() {
        powerOn = false
        pendingAfter = null
        voice.stopListening()
        voice.stopSpeaking()
        busy = AssistantState.READY
        errorMessage = null
        hint = "JARVIS is powered off. Listening has stopped."
        updateUi()
    }

    override fun openUrl(url: String): Boolean = try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    override fun say(text: String) = speakThen(text, null)
}
