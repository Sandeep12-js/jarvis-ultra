package com.sandeep.jarvis

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Locale

class SettingsActivity : AppCompatActivity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: Prefs
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private val languages = listOf(
        "English (India)" to "en-IN",
        "English (US)" to "en-US",
        "Hindi" to "hi-IN",
        "Punjabi" to "pa-IN"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = Prefs(this)
        tts = TextToSpeech(this) { ttsReady = (it == TextToSpeech.SUCCESS) }
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Palette.BG)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(TextView(this).apply {
            text = "\u2190"
            textSize = 26f
            setTextColor(Palette.CYAN)
            gravity = Gravity.CENTER
            contentDescription = "Back"
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(56), dp(56)))
        bar.addView(TextView(this).apply {
            text = "SETTINGS"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
            setTextColor(Palette.CYAN)
        })
        root.addView(bar, LinearLayout.LayoutParams(MATCH, dp(56)))

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }

        // 1
        list.addView(card("1. AI Models & Networks", "NOT IMPLEMENTED (Phase C)", Palette.GREY,
            "No AI provider is connected, so JARVIS cannot answer open questions yet. Provider setup, API keys and model selection are the next phase."))

        // 2
        val langName = languages.firstOrNull { it.second == prefs.language }?.first ?: prefs.language
        list.addView(card("2. Voice & Language", "WORKING (untested on device)", Palette.GREEN,
            "Language: $langName\nVoice: ${prefs.voiceName ?: "phone default"}\n\n" +
                "Only voices installed in your phone's text-to-speech engine can be used. " +
                "The voice am_onyx is not available in Android's built-in engine, so it cannot be offered yet.",
            action("Choose language") { pickLanguage() },
            action("Choose voice") { pickVoice() },
            action("Test voice") { testVoice() }))

        // 3
        list.addView(card("3. Modes & Behavior", "PARTIAL", Palette.ORANGE,
            "Current mode: ${AssistantMode.fromName(prefs.mode).label}\n" +
                "Switch modes from the side panel (\u2630) or by saying \"switch to pro mode\". " +
                "Modes are saved, but they will change AI behaviour only after an AI provider is connected."))

        // 4
        list.addView(card("4. Memory & Personalization", "NOT IMPLEMENTED (Phase E)", Palette.GREY,
            "No memory is stored. Nothing about you is saved except language, voice and mode."))

        // 5
        list.addView(card("5. Camera & Screen Sharing", "NOT IMPLEMENTED (Phase D)", Palette.GREY,
            "The camera and screen buttons on the main screen are placeholders for now."))

        // 6
        list.addView(card("6. Automation & Tools", "PARTIAL", Palette.ORANGE,
            "Working by voice: open YouTube, Instagram or the browser, search the web in your browser, tell the time and date.\n" +
                "Not built: accessibility control (tap, swipe, type), notes, reminders, files, floating bubble."))

        // 7
        val mic = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        list.addView(card("7. Privacy & Security", "PARTIAL", Palette.ORANGE,
            "Microphone permission: ${if (mic) "GRANTED" else "NOT GRANTED"}\n" +
                "JARVIS listens only while this app is open on screen and the mic is not muted. " +
                "There is no background listening and no wake word yet.\n" +
                "Network: only secure (HTTPS) connections are allowed. No camera or screen access exists in this build.",
            action("Open app permissions") {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }))

        // 8
        list.addView(card("8. System & Backup", "NOT IMPLEMENTED (Phase E/G)", Palette.GREY,
            "Backup, restore and diagnostics are not built yet."))

        // 9
        list.addView(card("9. Update Center", "NOT IMPLEMENTED", Palette.GREY,
            "To update, install a newer APK built by your GitHub Actions workflow over this one."))

        // 10
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        list.addView(card("10. About JARVIS", "", Palette.CYAN,
            "JARVIS-ULTRA\nSandeep Sir\n\nVersion $ver (early build)"))

        val scroll = ScrollView(this)
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
    }

    private fun card(title: String, status: String, statusColor: Int, body: String, vararg extra: View): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(0xFF0D1626.toInt())
                setStroke(dp(1), 0x3300E5FF)
            }
        }
        c.addView(TextView(this).apply {
            text = title
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Palette.CYAN)
        })
        if (status.isNotEmpty()) {
            c.addView(TextView(this).apply {
                text = status
                textSize = 11f
                letterSpacing = 0.08f
                setTextColor(statusColor)
                setPadding(0, dp(2), 0, dp(6))
            })
        }
        c.addView(TextView(this).apply {
            text = body
            textSize = 14f
            setTextColor(Palette.TEXT)
        })
        for (v in extra) c.addView(v)
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(12)
        c.layoutParams = lp
        return c
    }

    private fun action(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Palette.CYAN)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), Palette.CYAN)
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) }
    }

    private fun pickLanguage() {
        AlertDialog.Builder(this)
            .setTitle("Language")
            .setItems(languages.map { it.first }.toTypedArray()) { _, i ->
                prefs.language = languages[i].second
                prefs.voiceName = null
                build()
            }.show()
    }

    private fun pickVoice() {
        val engine = tts
        if (engine == null || !ttsReady) {
            Toast.makeText(this, "Voice engine is not ready.", Toast.LENGTH_SHORT).show()
            return
        }
        val loc = Locale.forLanguageTag(prefs.language)
        val voices = try {
            engine.voices?.filter { it.locale.language == loc.language }?.sortedBy { it.name }?.take(8)
                ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
        if (voices.isEmpty()) {
            Toast.makeText(
                this,
                "No installed voices for this language. Install voice data in Android Settings > Text-to-speech.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Voice")
            .setItems(voices.map { it.name + " (" + it.locale.displayName + ")" }.toTypedArray()) { _, i ->
                prefs.voiceName = voices[i].name
                build()
            }.show()
    }

    private fun testVoice() {
        val engine = tts
        if (engine == null || !ttsReady) {
            Toast.makeText(this, "Voice engine is not ready.", Toast.LENGTH_SHORT).show()
            return
        }
        engine.setLanguage(Locale.forLanguageTag(prefs.language))
        try {
            prefs.voiceName?.let { n -> engine.voices?.firstOrNull { it.name == n }?.let { engine.voice = it } }
        } catch (e: Exception) { }
        engine.setPitch(0.85f)
        engine.setSpeechRate(0.95f)
        engine.speak(Greetings.FIRST, TextToSpeech.QUEUE_FLUSH, null, "test")
    }
}
