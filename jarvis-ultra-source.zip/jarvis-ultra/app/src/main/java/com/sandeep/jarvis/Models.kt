package com.sandeep.jarvis

import android.content.Context
import android.graphics.Color

object Palette {
    val BG = Color.parseColor("#03060D")
    val CYAN = Color.parseColor("#00E5FF")
    val BLUE = Color.parseColor("#2979FF")
    val PURPLE = Color.parseColor("#B388FF")
    val GREEN = Color.parseColor("#00E676")
    val ORANGE = Color.parseColor("#FF6D00")
    val RED = Color.parseColor("#FF1744")
    val YELLOW = Color.parseColor("#FFD600")
    val GREY = Color.parseColor("#607D8B")
    val PANEL = Color.parseColor("#0D1626")
    val TEXT = Color.parseColor("#E6F7FF")
    val SUBTEXT = Color.parseColor("#8FA9BF")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

enum class AssistantState(val status: String, val orbLabel: String, val color: Int) {
    READY("JARVIS ONLINE", "SYSTEM READY", Palette.GREEN),
    LISTENING("LISTENING", "LISTENING...", Palette.CYAN),
    THINKING("THINKING", "THINKING...", Palette.PURPLE),
    SPEAKING("SPEAKING", "SPEAKING...", Palette.BLUE),
    STANDBY("STANDBY", "STANDBY", Palette.YELLOW),
    MUTED("MUTED", "MIC MUTED", Palette.RED),
    OFFLINE("OFFLINE", "POWER OFF", Palette.GREY),
    ERROR("ERROR", "ERROR", Palette.ORANGE)
}

// Order matters: JARVIS, GF MODE, PRO MODE, AGENT MODE
enum class AssistantMode(val label: String, val blurb: String) {
    JARVIS("JARVIS", "Full personal assistant"),
    GF("GF MODE", "Friendly, caring conversation"),
    PRO("PRO MODE", "Technical and professional"),
    AGENT("AGENT MODE", "Task-oriented agent");

    companion object {
        fun fromName(n: String?): AssistantMode =
            values().firstOrNull { it.name == n } ?: JARVIS
    }
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)

    var language: String
        get() = sp.getString("language", "en-IN") ?: "en-IN"
        set(v) { sp.edit().putString("language", v).apply() }

    var voiceName: String?
        get() = sp.getString("voiceName", null)
        set(v) { sp.edit().putString("voiceName", v).apply() }

    var mode: String
        get() = sp.getString("mode", AssistantMode.JARVIS.name) ?: AssistantMode.JARVIS.name
        set(v) { sp.edit().putString("mode", v).apply() }

    var greeted: Boolean
        get() = sp.getBoolean("greeted", false)
        set(v) { sp.edit().putBoolean("greeted", v).apply() }
}

object Greetings {
    const val FIRST = "Hi, I am JARVIS. System online. I am your personal AI assistant. How can I help you, Sir?"
    const val POWER_ON = "System online, Sir."
}
