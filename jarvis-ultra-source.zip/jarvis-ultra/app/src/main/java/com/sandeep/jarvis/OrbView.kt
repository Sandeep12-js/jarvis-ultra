package com.sandeep.jarvis

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Glowing energy orb. Animation style changes with the assistant state. */
class OrbView(context: Context) : View(context) {

    var state: AssistantState = AssistantState.READY
        set(value) {
            field = value
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()
    private val rnd = Random(7)
    private val pCount = 32
    private val pAngle = FloatArray(pCount) { rnd.nextFloat() * 6.2831855f }
    private val pRadius = FloatArray(pCount) { 0.5f + rnd.nextFloat() * 0.38f }
    private val pSize = FloatArray(pCount) { 1.5f + rnd.nextFloat() * 3f }
    private val pSpeed = FloatArray(pCount) {
        (0.2f + rnd.nextFloat() * 0.8f) * (if (rnd.nextBoolean()) 1f else -1f)
    }

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    private fun a(color: Int, alpha: Int): Int =
        (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) / 2f
        val sec = (SystemClock.uptimeMillis() % 3_600_000L) / 1000f
        val c = state.color

        val (amp, speed) = when (state) {
            AssistantState.READY -> 0.03f to 1.0f
            AssistantState.LISTENING -> 0.07f to 3.0f
            AssistantState.THINKING -> 0.04f to 6.0f
            AssistantState.SPEAKING -> 0.09f to 4.0f
            AssistantState.STANDBY -> 0.02f to 0.5f
            AssistantState.MUTED -> 0.015f to 0.3f
            AssistantState.OFFLINE -> 0f to 0f
            AssistantState.ERROR -> 0.05f to 8.0f
        }
        val dim = if (state == AssistantState.OFFLINE) 0.25f else 1f

        var breath = 1f + amp * sin(sec * 3.1415927f * speed)
        if (state == AssistantState.SPEAKING) breath += amp * 0.6f * sin(sec * 13f)

        // Outer glow
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx, cy, base,
            intArrayOf(a(c, (110 * dim).toInt()), a(c, (40 * dim).toInt()), a(c, 0)),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, base * (0.98f + (breath - 1f) * 0.5f), paint)

        // Core body
        val r = base * 0.58f * breath
        paint.shader = RadialGradient(
            cx - r * 0.2f, cy - r * 0.25f, r * 1.2f,
            intArrayOf(
                a(Color.WHITE, (230 * dim).toInt()),
                a(c, (220 * dim).toInt()),
                a(Palette.BLUE, (160 * dim).toInt())
            ),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, paint)
        paint.shader = null

        // Rotating rings
        ring.strokeWidth = base * 0.018f
        val rot = sec * 40f * speed
        for (k in 0..2) {
            val rr = base * (0.70f + k * 0.1f) * breath
            ring.color = a(if (k == 1) Palette.PURPLE else c, (170 * dim).toInt())
            canvas.save()
            canvas.rotate(if (k % 2 == 0) rot else -rot * 1.3f, cx, cy)
            rect.set(cx - rr, cy - rr, cx + rr, cy + rr)
            canvas.drawArc(rect, k * 40f, 90f + k * 30f, false, ring)
            canvas.drawArc(rect, 180f + k * 40f, 60f, false, ring)
            canvas.restore()
        }

        // Particles
        val density = resources.displayMetrics.density
        for (i in 0 until pCount) {
            val ang = pAngle[i] + sec * pSpeed[i] * (0.3f + 0.35f * speed)
            val rad = base * pRadius[i] * (1f + (breath - 1f) * 1.5f)
            val tw = 0.5f + 0.5f * sin(sec * 2f + i)
            paint.color = a(if (i % 5 == 0) Palette.PURPLE else c, ((60 + 150 * tw) * dim).toInt())
            canvas.drawCircle(cx + cos(ang) * rad, cy + sin(ang) * rad, pSize[i] * density * 0.6f, paint)
        }
    }
}
