package com.sandeep.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.FrameLayout
import android.text.InputType
import android.view.inputmethod.EditorInfo
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.io.ByteArrayOutputStream
import java.util.Locale

class MainActivity : AppCompatActivity(), VoiceEngine.Listener, CommandRouter.Host {

    private class Control(
        val root: LinearLayout,
        val frame: FrameLayout,
        val icon: ImageView,
        val caption: TextView
    )

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: Prefs
    private lateinit var voice: VoiceEngine
    private lateinit var brain: AiBrain
    private var aiToken = 0

    private lateinit var orb: OrbView
    private lateinit var miniOrb: OrbView
    private lateinit var previewView: PreviewView
    private lateinit var previewCard: FrameLayout
    private lateinit var statusView: TextView
    private lateinit var orbLabel: TextView
    private lateinit var camControl: Control
    private lateinit var screenControl: Control
    private lateinit var micControl: Control
    private lateinit var powerControl: Control
    private lateinit var micLed: View
    private val railButtons = LinkedHashMap<AssistantMode, LinearLayout>()

    private var powerOn = true
    private var muted = false
    private var resumed = false
    private var voiceReady = false
    private var busy = AssistantState.READY
    private var errorMessage: String? = null
    private var hint: String? = null
    private var pendingAfter: (() -> Unit)? = null

    private var visionOn = false
    private var lensBack = true
    private var cameraProvider: ProcessCameraProvider? = null
    private var screenPending = false
    private var lastErrorShown: String? = null

    override val currentMode: AssistantMode
        get() = AssistantMode.fromName(prefs.mode)

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                errorMessage = null
                hint = null
                startListeningIfAllowed()
            } else {
                hint = "Microphone permission denied. Enable it in phone Settings > Apps > JARVIS-ULTRA > Permissions."
            }
            updateUi()
        }

    private val camPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                openVision()
            } else {
                hint = "Camera permission denied. Enable it in phone Settings > Apps > JARVIS-ULTRA > Permissions."
                updateUi()
            }
        }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
            launchScreenCapture()
        }

    private val screenCapture =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val data = res.data
            if (res.resultCode == RESULT_OK && data != null) {
                screenPending = true
                voice.stopListening()
                voice.stopSpeaking()
                val i = Intent(this, ScreenAssistService::class.java)
                    .putExtra(ScreenAssistService.EXTRA_CODE, res.resultCode)
                    .putExtra(ScreenAssistService.EXTRA_DATA, data)
                try {
                    ContextCompat.startForegroundService(this, i)
                } catch (e: Exception) {
                    screenPending = false
                    hint = "Could not start screen sharing."
                }
            } else {
                hint = "Screen sharing was not allowed."
            }
            updateUi()
        }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = Prefs(this)
        brain = AiBrain(this)
        powerOn = prefs.powerOnDefault
        muted = prefs.micMutedDefault
        lensBack = prefs.useBackCamera
        buildUi()
        voice = VoiceEngine(this, prefs, this)
        updateUi()
        voice.init { onVoiceReady() }
    }

    private fun onVoiceReady() {
        voiceReady = true
        if (!micGranted()) {
            hint = "JARVIS needs the microphone to hear you. Please allow it."
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
        if (powerOn) {
            if (!prefs.greeted) {
                prefs.greeted = true
                speakThen(Greetings.FIRST, null)
            } else {
                startListeningIfAllowed()
            }
        }
        updateUi()
    }

    override fun onStart() {
        super.onStart()
        ScreenAssistService.onStateChanged = { runOnUiThread { screenStateChanged() } }
    }

    override fun onStop() {
        ScreenAssistService.onStateChanged = null
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        if (screenPending && ScreenAssistService.running) screenPending = false
        if (voiceReady) {
            voice.refreshVoice()
            startListeningIfAllowed()
        }
        updateUi()
        val typed = Conversation.pendingInput
        if (typed != null) {
            Conversation.pendingInput = null
            if (voiceReady && powerOn) {
                voice.stopListening()
                onHeard(typed)
            }
        }
    }

    override fun onPause() {
        resumed = false
        pendingAfter = null
        aiToken++
        closeVision()
        if (voiceReady) {
            voice.stopListening()
            voice.stopSpeaking()
        }
        if (busy == AssistantState.SPEAKING || busy == AssistantState.THINKING ||
            busy == AssistantState.LISTENING
        ) busy = AssistantState.READY
        super.onPause()
    }

    override fun onDestroy() {
        voice.destroy()
        super.onDestroy()
    }

    private fun sharing() = ScreenAssistService.running || screenPending

    private fun screenStateChanged() {
        if (ScreenAssistService.running) {
            screenPending = false
            hint = "Screen sharing is ON. JARVIS is listening in the background. Open any app and ask about your screen. Tap SCREEN to stop."
        } else {
            screenPending = false
            hint = "Screen sharing stopped."
            startListeningIfAllowed()
        }
        updateUi()
    }

    // ------------------------------------------------------------ UI building

    private fun glass(radius: Int, fill: Int, strokeColor: Int): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(radius).toFloat()
            setColor(fill)
            setStroke(dp(1), strokeColor)
        }

    private fun modeButton(m: AssistantMode): LinearLayout {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            contentDescription = m.label
            setOnClickListener {
                switchMode(m)
                speakThen("${m.label} selected, Sir.", null)
            }
        }
        col.addView(TextView(this).apply {
            text = m.glyph
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(m.color)
            gravity = Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = m.short
            textSize = 8.5f
            letterSpacing = 0.08f
            setTextColor(Palette.TEXT)
            gravity = Gravity.CENTER
        })
        return col
    }

    private fun buildUi() {
        val content = FrameLayout(this).apply { setBackgroundColor(Palette.BG) }
        content.addView(HudBackground(this), FrameLayout.LayoutParams(MATCH, MATCH))
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        content.addView(main, FrameLayout.LayoutParams(MATCH, MATCH))

        // Header: title (center) | settings gear (right)
        val header = FrameLayout(this)
        header.addView(TextView(this).apply {
            text = "JARVIS-ULTRA"
            textSize = 27f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
            setTextColor(Palette.CYAN)
            gravity = Gravity.CENTER
            setShadowLayer(20f, 0f, 0f, Palette.CYAN)
        }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        header.addView(TextView(this).apply {
            text = "\u2699"
            textSize = 26f
            setTextColor(Palette.CYAN)
            gravity = Gravity.CENTER
            contentDescription = "Settings"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END or Gravity.CENTER_VERTICAL))
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher_fg)
            contentDescription = "JARVIS logo"
        }, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.START or Gravity.CENTER_VERTICAL).apply { leftMargin = dp(12) })
        main.addView(header, LinearLayout.LayoutParams(MATCH, dp(68)))

        // Status capsule
        statusView = TextView(this).apply {
            textSize = 12.5f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.16f
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(5), dp(18), dp(5))
        }


        main.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        // Stage: voice interface (or live camera view) with the four modes on the right
        val stage = FrameLayout(this)
        orb = OrbView(this)
        orb.setOnClickListener { onOrbTapped() }
        stage.addView(orb, FrameLayout.LayoutParams(dp(290), dp(290), Gravity.CENTER))

        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        previewCard = FrameLayout(this).apply {
            visibility = View.GONE
            background = glass(18, 0xFF050B14.toInt(), 0x9900E5FF.toInt())
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(18).toFloat())
                }
            }
            setOnClickListener { askFrame("What do you see? Explain briefly.") }
        }
        previewCard.addView(previewView, FrameLayout.LayoutParams(MATCH, MATCH))
        previewCard.addView(TextView(this).apply {
            text = "\u25CF VISION LIVE"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
            setTextColor(Palette.GREEN)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = glass(10, 0x99000000.toInt(), Palette.GREEN)
        }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).apply {
            topMargin = dp(10); leftMargin = dp(10)
        })
        miniOrb = OrbView(this)
        previewCard.addView(miniOrb, FrameLayout.LayoutParams(dp(78), dp(78), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(4); rightMargin = dp(4)
        })
        previewCard.addView(TextView(this).apply {
            text = "Tap to ask \u2022 or just speak"
            textSize = 11f
            setTextColor(Palette.TEXT)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = glass(10, 0x99000000.toInt(), 0x3300E5FF)
        }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).apply {
            bottomMargin = dp(10); leftMargin = dp(10)
        })
        previewCard.addView(TextView(this).apply {
            text = "\u27F2"
            textSize = 22f
            setTextColor(Palette.CYAN)
            gravity = Gravity.CENTER
            contentDescription = "Switch camera"
            background = glass(22, 0x99000000.toInt(), 0x6600E5FF)
            setOnClickListener {
                lensBack = !lensBack
                bindCamera()
            }
        }, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM or Gravity.END).apply {
            bottomMargin = dp(8); rightMargin = dp(8)
        })
        stage.addView(previewCard, FrameLayout.LayoutParams(MATCH, MATCH).apply {
            leftMargin = dp(16); rightMargin = dp(16); topMargin = dp(6); bottomMargin = dp(6)
        })

        main.addView(stage, LinearLayout.LayoutParams(MATCH, dp(320)))

        orbLabel = TextView(this).apply {
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.22f
            gravity = Gravity.CENTER
        }


        main.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        // Type a command (keyboard input)
        val typeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = glass(24, 0x66091526, 0x6600E5FF)
            setPadding(dp(14), dp(2), dp(4), dp(2))
        }
        val cmd = EditText(this).apply {
            hint = "Type a command..."
            setHintTextColor(Palette.SUBTEXT)
            setTextColor(Palette.TEXT)
            textSize = 14f
            setSingleLine(true)
            background = null
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
        }
        fun sendTyped() {
            val t = cmd.text.toString().trim()
            if (t.isNotEmpty()) {
                cmd.setText("")
                voice.stopListening()
                onHeard(t)
            }
        }
        cmd.setOnEditorActionListener { _, _, _ -> sendTyped(); true }
        typeRow.addView(cmd, LinearLayout.LayoutParams(0, WRAP, 1f))
        typeRow.addView(TextView(this).apply {
            text = "\u27A4"
            textSize = 18f
            setTextColor(Palette.BG)
            gravity = Gravity.CENTER
            background = glass(20, Palette.BLUE, Palette.BLUE)
            setOnClickListener { sendTyped() }
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        main.addView(typeRow, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            leftMargin = dp(20)
            rightMargin = dp(20)
            topMargin = dp(8)
        })

        // Exactly four bottom controls, inside a glass dock
        camControl = control(R.drawable.ic_camera, "CAMERA", Palette.CYAN) { onCameraTapped() }
        screenControl = control(R.drawable.ic_screen, "SCREEN", Palette.BLUE) { onScreenTapped() }
        micControl = control(R.drawable.ic_mic, "MIC", Palette.CYAN) { onMicTapped() }

        powerControl = control(R.drawable.ic_power, "POWER", Palette.GREEN) { onPowerTapped() }

        micLed = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Palette.YELLOW) }
        }
        micControl.frame.addView(
            micLed,
            FrameLayout.LayoutParams(dp(14), dp(14), Gravity.TOP or Gravity.END)
        )

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = glass(30, 0x66091526, 0x4400E5FF)
            setPadding(dp(6), dp(12), dp(6), dp(8))
        }
        for (c in listOf(camControl, screenControl, micControl, powerControl)) {
            dock.addView(c.root, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        main.addView(dock, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            leftMargin = dp(14)
            rightMargin = dp(14)
            topMargin = dp(8)
        })

        setContentView(content)

        ViewCompat.setOnApplyWindowInsetsListener(main) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom + dp(10))
            insets
        }
    }

    /** 3D-looking glossy button: dark radial body, glowing rim, top highlight. */
    private fun glossy(accent: Int): LayerDrawable {
        val body = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = dp(40).toFloat()
            colors = intArrayOf(0xFF1C3A57.toInt(), 0xFF0B1C2E.toInt(), 0xFF050B14.toInt())
            setStroke(dp(3), accent)
        }
        val shine = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            gradientType = GradientDrawable.LINEAR_GRADIENT
            orientation = GradientDrawable.Orientation.TOP_BOTTOM
            colors = intArrayOf(0x88FFFFFF.toInt(), 0x00FFFFFF)
        }
        val layer = LayerDrawable(arrayOf<Drawable>(body, shine))
        layer.setLayerInset(1, dp(10), dp(4), dp(10), dp(34))
        return layer
    }

    private fun control(iconRes: Int, caption: String, accent: Int, onClick: () -> Unit): Control {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val frame = FrameLayout(this)
        val icon = ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(accent)
            setPadding(dp(18), dp(18), dp(18), dp(18))
            contentDescription = caption
            background = glossy(accent)
            setOnClickListener { onClick() }
        }
        frame.addView(icon, FrameLayout.LayoutParams(dp(62), dp(62), Gravity.CENTER))
        col.addView(frame, LinearLayout.LayoutParams(dp(72), dp(72)))
        val cap = TextView(this).apply {
            text = caption
            textSize = 10.5f
            letterSpacing = 0.14f
            setTextColor(Palette.SUBTEXT)
            gravity = Gravity.CENTER
        }
        col.addView(cap, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(4) })
        return Control(col, frame, icon, cap)
    }

    // ------------------------------------------------------------ state / UI refresh

    private fun micGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun camGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    private fun effectiveState(): AssistantState = when {
        !powerOn -> AssistantState.OFFLINE
        errorMessage != null -> AssistantState.ERROR
        sharing() -> AssistantState.SHARING
        busy == AssistantState.SPEAKING || busy == AssistantState.THINKING -> busy
        muted -> AssistantState.MUTED
        !micGranted() -> AssistantState.STANDBY
        else -> busy
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun updateUi() {
        val st = effectiveState()
        orb.state = st
        miniOrb.state = st
        statusView.text = "\u25CF " + st.status
        statusView.setTextColor(st.color)
        statusView.background = GradientDrawable().apply {
            cornerRadius = dp(22).toFloat()
            setColor((st.color and 0x00FFFFFF) or 0x22000000)
            setStroke(dp(1), st.color)
        }
        orbLabel.text = st.orbLabel
        orbLabel.setTextColor(st.color)

        // Messages are shown briefly as toasts (the screen stays clean); the conversation is in Settings.
        val msg = hint
        if (msg != null) {
            hint = null
            toast(msg)
        }
        val err = errorMessage
        if (err != null && err != lastErrorShown) {
            lastErrorShown = err
            toast(err)
        }
        if (err == null) lastErrorShown = null

        val led = when {
            !powerOn -> Palette.GREY
            muted -> Palette.RED
            st == AssistantState.LISTENING -> Palette.GREEN
            else -> Palette.YELLOW
        }
        (micLed.background as GradientDrawable).setColor(led)
        micControl.icon.setColorFilter(if (muted) Palette.RED else Palette.CYAN)
        powerControl.icon.setColorFilter(if (powerOn) Palette.GREEN else Palette.GREY)
        camControl.icon.setColorFilter(if (visionOn) Palette.GREEN else Palette.CYAN)
        camControl.caption.text = if (visionOn) "LIVE" else "CAMERA"
        screenControl.icon.setColorFilter(if (sharing()) Palette.GREEN else Palette.BLUE)
        screenControl.caption.text = if (sharing()) "SHARING" else "SCREEN"

        for ((m, v) in railButtons) {
            val sel = m == currentMode
            v.background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(if (sel) (m.color and 0x00FFFFFF) or 0x33000000 else 0x22091526)
                setStroke(dp(if (sel) 2 else 1), if (sel) m.color else (m.color and 0x00FFFFFF) or 0x66000000)
            }
        }
    }

    /** Tap the sphere: interrupt speech, or start listening now. */
    private fun onOrbTapped() {
        if (!powerOn) {
            hint = "JARVIS is powered off. Tap the power button first."
            updateUi()
            return
        }
        when (effectiveState()) {
            AssistantState.SPEAKING -> {
                pendingAfter = null
                voice.stopSpeaking()
                busy = AssistantState.READY
                updateUi()
                startListeningIfAllowed()
            }
            AssistantState.THINKING, AssistantState.SHARING -> { }
            else -> startListeningIfAllowed()
        }
    }

    // ------------------------------------------------------------ user actions

    private fun onMicTapped() {
        if (!powerOn) {
            hint = "JARVIS is powered off. Tap the power button first."
            updateUi()
            return
        }
        if (sharing()) {
            hint = "While screen sharing is on, JARVIS listens in the background. Tap SCREEN to stop sharing first."
            updateUi()
            return
        }
        if (errorMessage != null) {            // retry after a failure
            errorMessage = null
            hint = null
            if (!micGranted()) micPermission.launch(Manifest.permission.RECORD_AUDIO)
            else startListeningIfAllowed()
            updateUi()
            return
        }
        muted = !muted
        prefs.micMutedDefault = muted
        if (muted) {
            voice.stopListening()
            hint = "Microphone muted. JARVIS cannot hear you."
        } else {
            hint = null
            if (!micGranted()) micPermission.launch(Manifest.permission.RECORD_AUDIO)
            else startListeningIfAllowed()
        }
        updateUi()
    }

    private fun onPowerTapped() {
        if (powerOn) powerOff() else powerOnNow()
    }

    private fun powerOnNow() {
        powerOn = true
        errorMessage = null
        hint = null
        speakThen(Greetings.POWER_ON, null)
        updateUi()
    }

    private fun startListeningIfAllowed() {
        if (!resumed || !voiceReady || !powerOn || muted || errorMessage != null) return
        if (sharing()) return
        if (busy == AssistantState.SPEAKING || busy == AssistantState.THINKING) return
        if (!micGranted()) return
        voice.startListening()
    }

    private fun speakThen(text: String, after: (() -> Unit)?) {
        pendingAfter = after
        Conversation.add("JARVIS", text)
        busy = AssistantState.THINKING
        updateUi()
        voice.speak(text)
    }

    // ------------------------------------------------------------ live camera vision

    private fun onCameraTapped() {
        if (visionOn) {
            closeVision()
            hint = "Camera off."
            updateUi()
            return
        }
        if (!powerOn) {
            hint = "JARVIS is powered off. Tap the power button first."
            updateUi()
            return
        }
        if (sharing()) {
            hint = "Stop screen sharing first. Camera and screen sharing cannot run together."
            updateUi()
            return
        }
        if (!brain.hasProvider()) {
            hint = "Camera vision needs an AI provider that understands images, for example Google Gemini. " +
                "Add a key in Settings > AI & Intelligence Settings."
            updateUi()
            return
        }
        if (!camGranted()) {
            camPermission.launch(Manifest.permission.CAMERA)
            return
        }
        openVision()
    }

    private fun openVision() {
        visionOn = true
        orb.visibility = View.GONE
        previewCard.visibility = View.VISIBLE
        bindCamera()
        speakThen("Camera is on, Sir. Show me something and ask.", null)
    }

    private fun closeVision() {
        if (!visionOn) return
        visionOn = false
        try {
            cameraProvider?.unbindAll()
        } catch (e: Exception) {
            // already released
        }
        previewCard.visibility = View.GONE
        orb.visibility = View.VISIBLE
        updateUi()
    }

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener(Runnable {
            try {
                val provider = future.get()
                cameraProvider = provider
                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(previewView.surfaceProvider)
                val selector =
                    if (lensBack) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, preview)
            } catch (e: Exception) {
                hint = "Could not start the camera."
                closeVision()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun askFrame(question: String) {
        if (!visionOn) return
        if (busy == AssistantState.THINKING || busy == AssistantState.SPEAKING) return
        val bmp = previewView.bitmap
        if (bmp == null) {
            speakThen("The camera is not ready yet, Sir.", null)
            return
        }
        sendImage(bmp, question, "camera")
    }

    private fun sendImage(bmp: Bitmap, question: String, source: String) {
        val token = ++aiToken
        busy = AssistantState.THINKING
        Conversation.add("You (" + source + ")", question)
        updateUi()
        val mode = currentMode
        Thread {
            val longest = maxOf(bmp.width, bmp.height)
            val send = if (longest > 1280) {
                val s = 1280f / longest
                Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
            } else bmp
            val bos = ByteArrayOutputStream()
            send.compress(Bitmap.CompressFormat.JPEG, 80, bos)
            val r = brain.askWithImage(question, bos.toByteArray(), mode, source)
            runOnUiThread { deliverAi(token, r) }
        }.start()
    }

    // ------------------------------------------------------------ screen sharing

    private fun onScreenTapped() {
        if (sharing()) {
            stopService(Intent(this, ScreenAssistService::class.java))
            screenPending = false
            hint = "Screen sharing stopped."
            updateUi()
            startListeningIfAllowed()
            return
        }
        if (!powerOn) {
            hint = "JARVIS is powered off. Tap the power button first."
            updateUi()
            return
        }
        if (!brain.hasProvider()) {
            hint = "Screen understanding needs an AI provider that understands images, for example Google Gemini. " +
                "Add a key in Settings > AI & Intelligence Settings."
            updateUi()
            return
        }
        if (!micGranted()) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        closeVision()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            launchScreenCapture()
        }
    }

    private fun launchScreenCapture() {
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            screenCapture.launch(mpm.createScreenCaptureIntent())
        } catch (e: Exception) {
            hint = "Could not open Android's screen-sharing permission."
            updateUi()
        }
    }

    // ------------------------------------------------------------ AI

    private fun deliverAi(token: Int, r: AiResult) {
        if (token != aiToken || !powerOn || isFinishing) return
        val answer = r.text
        if (answer != null) {
            Toast.makeText(this, "JARVIS: " + answer.take(220), Toast.LENGTH_LONG).show()
            speakThen(forSpeech(answer), null)
        } else {
            speakThen("Sorry Sir, I could not get an answer from the AI.", null)
            val e = r.error ?: "unknown"
            Conversation.add("AI error", e)
            hint = "AI error: " + e.lines().first()
            updateUi()
        }
    }

    private fun askAi(text: String) {
        if (!brain.hasProvider()) {
            speakThen(
                "AI is not connected yet, Sir. Open Settings, then AI and Intelligence Settings, and add a free Gemini key.",
                null
            )
            return
        }
        val token = ++aiToken
        busy = AssistantState.THINKING
        updateUi()
        val mode = currentMode
        Thread {
            val r = brain.ask(text, mode)
            runOnUiThread { deliverAi(token, r) }
        }.start()
    }

    private fun forSpeech(t: String): String =
        t.replace(Regex("[*_`#>]"), "").replace(Regex("\\s+"), " ").trim().take(900)

    // ------------------------------------------------------------ VoiceEngine.Listener

    override fun onHeard(text: String) {
        busy = AssistantState.THINKING
        Conversation.add("You", text)
        updateUi()
        val lower = text.lowercase(Locale.ROOT)
        if (visionOn) {
            if (Regex("close camera|stop camera|camera off|turn off camera|camera band").containsMatchIn(lower)) {
                closeVision()
                speakThen("Camera off, Sir.", null)
                return
            }
            val camPhrase = Regex("in front of me|look at this|read this text|open camera|take a (photo|picture)")
                .containsMatchIn(lower)
            val local = CommandRouter.handle(text, this)
            if (local != null && !camPhrase) {
                speakThen(local.text, local.after)
            } else {
                busy = AssistantState.READY
                askFrame(text)
            }
            return
        }
        val reply = CommandRouter.handle(text, this)
        if (reply != null) {
            speakThen(reply.text, reply.after)
        } else {
            askAi(text)
        }
    }

    override fun onListeningStarted() {
        if (busy != AssistantState.SPEAKING && busy != AssistantState.THINKING) {
            busy = AssistantState.LISTENING
            updateUi()
        }
    }

    override fun onVoiceError(message: String, fatal: Boolean) {
        if (fatal) errorMessage = message else hint = message
        updateUi()
    }

    override fun onLevel(level: Float) {
        orb.level = level
        miniOrb.level = level
    }

    override fun onSpeakStart() {
        busy = AssistantState.SPEAKING
        updateUi()
    }

    override fun onSpeakDone() {
        busy = AssistantState.READY
        val after = pendingAfter
        pendingAfter = null
        after?.invoke()
        startListeningIfAllowed()
        updateUi()
    }

    // ------------------------------------------------------------ CommandRouter.Host

    override fun switchMode(mode: AssistantMode) {
        prefs.mode = mode.name
        updateUi()
    }

    override fun muteMic() {
        muted = true
        voice.stopListening()
        updateUi()
    }

    override fun powerOff() {
        powerOn = false
        aiToken++
        pendingAfter = null
        closeVision()
        if (sharing()) {
            stopService(Intent(this, ScreenAssistService::class.java))
            screenPending = false
        }
        voice.stopListening()
        voice.stopSpeaking()
        busy = AssistantState.READY
        errorMessage = null
        hint = "JARVIS is powered off. Listening has stopped."
        updateUi()
    }

    override fun openUrl(url: String): Boolean = try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    override fun openCamera() {
        if (!visionOn) onCameraTapped()
    }

    override fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    override fun openScreenShare() {
        if (!sharing()) onScreenTapped()
    }

    override fun say(text: String) = speakThen(text, null)
}
