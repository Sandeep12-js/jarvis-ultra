# JARVIS-ULTRA (early build 0.2.0)

Native Android (Kotlin) voice assistant. This build is Phase A + B only.

## What works in this build (not yet device-tested)
- Main screen: title, status, animated energy orb, exactly four bottom controls
- Side panel with modes in order: JARVIS, GF MODE, PRO MODE, AGENT MODE
- Speech recognition + text-to-speech, mic mute/unmute with LED, power on/off
- Voice commands: developer question, mode switching, mute, power off, time/date,
  open YouTube / Instagram / browser, web search in browser
- Settings with 10 sections (honest status on each)

## Not built yet
Camera vision, screen sharing, memory, backup, accessibility
control, wake word, background service, floating bubble, web-search API.

## Build
Use the GitHub Actions workflow (build.yml). Output: JARVIS-ULTRA-apk artifact
containing app-debug.apk (debug-signed, installable on any phone).
