package com.sandeep.jarvis

import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Local voice commands that work without any AI provider.
 * Replies describe only what the app really does.
 */
object CommandRouter {

    interface Host {
        val currentMode: AssistantMode
        fun switchMode(mode: AssistantMode)
        fun muteMic()
        fun powerOff()
        fun openUrl(url: String): Boolean
        fun openCamera()
        fun say(text: String)
    }

    class Reply(val text: String, val after: (() -> Unit)? = null)

    /** Returns null when no local command matches (the AI should answer instead). */
    fun handle(raw: String, host: Host): Reply? {
        val t = raw.lowercase(Locale.ROOT)
            .replace(Regex("[?.!,]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .replace(Regex("^(hey |ok |okay )?jarvis ?"), "")

        // Developer identity
        if (Regex("who (developed|made|created|built|designed|programmed) you|your (developer|creator|maker)|kisne banaya")
                .containsMatchIn(t)
        ) {
            return Reply("Sandeep Sir.")
        }

        if (Regex("who are you|what is your name|introduce yourself").containsMatchIn(t)) {
            return Reply("I am JARVIS, your personal AI assistant.")
        }

        // Mode switching
        val mode = when {
            Regex("\\bg ?f mode\\b|girlfriend mode").containsMatchIn(t) -> AssistantMode.GF
            Regex("\\bpro mode\\b|professional mode").containsMatchIn(t) -> AssistantMode.PRO
            "agent mode" in t -> AssistantMode.AGENT
            "jarvis mode" in t || "normal mode" in t -> AssistantMode.JARVIS
            else -> null
        }
        if (mode != null) {
            host.switchMode(mode)
            return Reply(
                when (mode) {
                    AssistantMode.JARVIS -> "JARVIS mode active, Sir."
                    AssistantMode.GF -> "GF mode active. I'm here for you, Sir."
                    AssistantMode.PRO -> "Pro mode active. Technical assistance ready."
                    AssistantMode.AGENT -> "Agent mode selected. Task tools are not built yet, so for now I can only open apps and search the web."
                }
            )
        }

        // Mic / power
        if (Regex("\\b(mute|stop listening)\\b").containsMatchIn(t) && "unmute" !in t) {
            host.muteMic()
            return Reply("Microphone muted, Sir. Tap the mic button to unmute.")
        }
        if (Regex("power off|shut down jarvis|go offline|turn off jarvis").containsMatchIn(t)) {
            return Reply("Powering down, Sir.") { host.powerOff() }
        }

        if (Regex("what is in front of me|open camera|take a photo|take a picture|look at this|read this text").containsMatchIn(t)) {
            return Reply("Opening the camera, Sir.") { host.openCamera() }
        }

        // Time and date (real device clock)
        if (Regex("what time|time is it|current time").containsMatchIn(t)) {
            val now = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            return Reply("It is $now, Sir.")
        }
        if (Regex("what date|today's date|what day").containsMatchIn(t)) {
            val now = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
            return Reply("Today is $now.")
        }

        // Web search via the phone's browser
        val search = Regex("\\b(?:search|google)\\b(?: for)? (.+)").find(t)
        if (search != null) {
            val query = search.groupValues[1]
                .replace(Regex(" (on|in) (the )?(internet|google|web)$"), "")
                .trim()
            if (query.isNotEmpty()) {
                val url = "https://www.google.com/search?q=" + Uri.encode(query)
                return Reply("Searching the web for $query.") {
                    if (!host.openUrl(url)) host.say("Sorry Sir, I could not open the browser.")
                }
            }
        }

        // Open apps / sites
        val open = Regex("^(?:open|launch|start) (.+)$").find(t)
        if (open != null) {
            val target = open.groupValues[1]
            val (label, url) = when {
                "youtube" in target -> "YouTube" to "https://www.youtube.com"
                "instagram" in target -> "Instagram" to "https://www.instagram.com"
                "browser" in target || "chrome" in target || "google" in target ->
                    "the browser" to "https://www.google.com"
                else -> null to null
            }
            if (label != null && url != null) {
                return Reply("Opening $label, Sir.") {
                    if (!host.openUrl(url)) host.say("Sorry Sir, I could not open $label.")
                }
            }
            return Reply("I can only open YouTube, Instagram and the browser right now, Sir. Other apps come with the automation phase.")
        }

        if (Regex("what can you do|your features").containsMatchIn(t)) {
            return Reply("I can talk with you using AI, switch modes, tell the time, open YouTube, Instagram and the browser, and search the web. Camera and screen understanding are not built yet.")
        }

        return null
    }
}
