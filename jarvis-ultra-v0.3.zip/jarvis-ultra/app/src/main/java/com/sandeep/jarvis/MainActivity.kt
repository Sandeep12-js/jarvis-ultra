package com.sandeep.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.drawerlayout.widget.DrawerLayout
import java.io.ByteArrayOutputStream
import java.io.File

class MainActivity : AppCompatActivity(), VoiceEngine.Listener, CommandRouter.Host {

    private class Control(val root: LinearLayout, val frame: FrameLayout, val icon: ImageView)

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: Prefs
    private lateinit var voice: VoiceEngine
    private lateinit var brain: AiBrain
    private var aiToken = 0
    private lateinit var orb: OrbView
    private lateinit var statusView: TextView
    private lateinit var orbLabel: TextView
    private lateinit var hintView: TextView
    private lateinit var hintCard: ScrollView
    private lateinit var modeView: TextView
    private lateinit var drawer: DrawerLayout
    private lateinit var micControl: Control
    private lateinit var powerControl: Control
    private lateinit var micLed: View
    private val modeRows = LinkedHashMap<AssistantMode, TextView>()

    private var powerOn = true
    private var muted = false
    private var resumed = false
    private var voiceReady = false
    private var busy = AssistantState.READY
    private var errorMessage: String? = null
    private var hint: String? = null
    private var pendingAfter: (() -> Unit)? = null
    private var photoFile: File? = null

    override val currentMode: AssistantMode
        get() = AssistantMode.fromName(prefs.mode)

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                errorMessage = null
                hint = null
                startListeningIfAllowed()
            } else {
                hint = "Microphone permission denied. Enable it in phone Settings > Apps > JARVIS-ULTRA > Permissions."
            }
            updateUi()
        }

    private val takePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            val f = photoFile
            if (ok && f != null && f.exists() && f.length() > 0) {
                showPhotoDialog(f)
            } else {
                hint = "No photo was taken."
                updateUi()
            }
        }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = Prefs(this)
        brain = AiBrain(this)
        buildUi()
        voice = VoiceEngine(this, prefs, this)
        updateUi()
        voice.init { onVoiceReady() }
    }

    private fun onVoiceReady() {
        voiceReady = true
        if (!micGranted()) {
            hint = "JARVIS needs the microphone to hear you. Please allow it."
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
        if (powerOn) {
            if (!prefs.greeted) {
                prefs.greeted = true
                speakThen(Greetings.FIRST, null)
            } else {
                startListeningIfAllowed()
            }
        }
        updateUi()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        if (voiceReady) {
            voice.refreshVoice()
            startListeningIfAllowed()
        }
        updateUi()
    }

    override fun onPause() {
        resumed = false
        pendingAfter = null
        aiToken++
        if (voiceReady) {
            voice.stopListening()
            voice.stopSpeaking()
        }
        if (busy == AssistantState.SPEAKING || busy == AssistantState.THINKING ||
            busy == AssistantState.LISTENING
        ) busy = AssistantState.READY
        super.onPause()
    }

    override fun onDestroy() {
        voice.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------ UI building

    private fun glass(radius: Int, fill: Int, strokeColor: Int): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(radius).toFloat()
            setColor(fill)
            setStroke(dp(1), strokeColor)
        }

    private fun buildUi() {
        drawer = DrawerLayout(this)
        val content = FrameLayout(this).apply { setBackgroundColor(Palette.BG) }
        content.addView(HudBackground(this), FrameLayout.LayoutParams(MATCH, MATCH))
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        content.addView(main, FrameLayout.LayoutParams(MATCH, MATCH))

        // Header: menu (left) | title + subtitle (center) | gear (right)
        val header = FrameLayout(this)
        val menu = TextView(this).apply {
            text = "\u2630"
            textSize = 24f
            setTextColor(Palette.CYAN)
            gravity = Gravity.CENTER
            contentDescription = "Assistant modes"
            setOnClickListener { drawer.openDrawer(GravityCompat.START) }
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        titleBox.addView(TextView(this).apply {
            text = "JARVIS-ULTRA"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
            setTextColor(Palette.CYAN)
            gravity = Gravity.CENTER
            setShadowLayer(18f, 0f, 0f, Palette.CYAN)
        })
        titleBox.addView(TextView(this).apply {
            text = "PERSONAL AI ASSISTANT"
            textSize = 9.5f
            letterSpacing = 0.35f
            setTextColor(Palette.SUBTEXT)
            gravity = Gravity.CENTER
        })
        val gear = TextView(this).apply {
            text = "\u2699"
            textSize = 24f
            setTextColor(Palette.SUBTEXT)
            gravity = Gravity.CENTER
            contentDescription = "Settings"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        header.addView(menu, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.START or Gravity.CENTER_VERTICAL))
        header.addView(titleBox, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        header.addView(gear, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END or Gravity.CENTER_VERTICAL))
        main.addView(header, LinearLayout.LayoutParams(MATCH, dp(68)))

        // Status capsule
        statusView = TextView(this).apply {
            textSize = 12.5f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.16f
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(6), dp(18), dp(6))
        }
        main.addView(statusView, LinearLayout.LayoutParams(WRAP, WRAP).apply {
            topMargin = dp(2)
            gravity = Gravity.CENTER_HORIZONTAL
        })

        modeView = TextView(this).apply {
            textSize = 11f
            setTextColor(Palette.SUBTEXT)
            letterSpacing = 0.14f
            gravity = Gravity.CENTER
        }
        main.addView(modeView, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })

        main.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        orb = OrbView(this)
        main.addView(orb, LinearLayout.LayoutParams(dp(250), dp(250)))

        orbLabel = TextView(this).apply {
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.22f
            gravity = Gravity.CENTER
        }
        main.addView(orbLabel, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        // Conversation card
        hintView = TextView(this).apply {
            textSize = 13.5f
            setTextColor(Palette.TEXT)
            setLineSpacing(0f, 1.1f)
        }
        hintCard = ScrollView(this).apply {
            background = glass(16, 0x33091526, 0x4400E5FF)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            addView(hintView)
        }
        main.addView(hintCard, LinearLayout.LayoutParams(MATCH, dp(104)).apply {
            leftMargin = dp(20)
            rightMargin = dp(20)
            topMargin = dp(10)
        })

        main.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        // Exactly four bottom controls, inside a glass dock
        val camera = control(R.drawable.ic_camera, "CAMERA", Palette.CYAN) { onCameraTapped() }
        val screen = control(R.drawable.ic_screen, "SCREEN", Palette.BLUE) {
            Toast.makeText(this, "Screen sharing arrives in the next update.", Toast.LENGTH_LONG).show()
        }
        micControl = control(R.drawable.ic_mic, "MIC", Palette.CYAN) { onMicTapped() }
        powerControl = control(R.drawable.ic_power, "POWER", Palette.GREEN) { onPowerTapped() }

        micLed = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Palette.YELLOW) }
        }
        micControl.frame.addView(
            micLed,
            FrameLayout.LayoutParams(dp(14), dp(14), Gravity.TOP or Gravity.END)
        )

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = glass(30, 0x66091526, 0x4400E5FF)
            setPadding(dp(6), dp(14), dp(6), dp(10))
        }
        for (c in listOf(camera, screen, micControl, powerControl)) {
            dock.addView(c.root, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        main.addView(dock, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            leftMargin = dp(14)
            rightMargin = dp(14)
            topMargin = dp(10)
        })

        // Side panel with the four modes, in order
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Palette.PANEL)
            setPadding(dp(16), dp(64), dp(16), dp(16))
        }
        panel.addView(TextView(this).apply {
            text = "ASSISTANT MODES"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.18f
            setTextColor(Palette.CYAN)
            setPadding(0, 0, 0, dp(16))
        })
        val glyphs = mapOf(
            AssistantMode.JARVIS to "\u25C9",
            AssistantMode.GF to "\u2665",
            AssistantMode.PRO to "</>",
            AssistantMode.AGENT to "\u25B6"
        )
        for (m in AssistantMode.values()) {
            val rowView = TextView(this).apply {
                text = (glyphs[m] ?: "") + "  " + m.label + "\n" + m.blurb
                textSize = 15f
                setTextColor(Palette.TEXT)
                setPadding(dp(14), dp(14), dp(14), dp(14))
                setOnClickListener {
                    drawer.closeDrawer(GravityCompat.START)
                    switchMode(m)
                    speakThen("${m.label} selected, Sir.", null)
                }
            }
            modeRows[m] = rowView
            panel.addView(rowView, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) })
        }

        drawer.addView(content, DrawerLayout.LayoutParams(MATCH, MATCH))
        drawer.addView(panel, DrawerLayout.LayoutParams(dp(270), MATCH, Gravity.START))
        setContentView(drawer)

        ViewCompat.setOnApplyWindowInsetsListener(main) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom + dp(10))
            insets
        }
    }

    private fun control(iconRes: Int, caption: String, accent: Int, onClick: () -> Unit): Control {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val frame = FrameLayout(this)
        val icon = ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(accent)
            setPadding(dp(18), dp(18), dp(18), dp(18))
            contentDescription = caption
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x2200E5FF)
                setStroke(dp(2), accent)
            }
            setOnClickListener { onClick() }
        }
        frame.addView(icon, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER))
        col.addView(frame, LinearLayout.LayoutParams(dp(74), dp(74)))
        col.addView(TextView(this).apply {
            text = caption
            textSize = 10.5f
            letterSpacing = 0.14f
            setTextColor(Palette.SUBTEXT)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })
        return Control(col, frame, icon)
    }

    // ------------------------------------------------------------ state / UI refresh

    private fun micGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun effectiveState(): AssistantState = when {
        !powerOn -> AssistantState.OFFLINE
        errorMessage != null -> AssistantState.ERROR
        busy == AssistantState.SPEAKING || busy == AssistantState.THINKING -> busy
        muted -> AssistantState.MUTED
        !micGranted() -> AssistantState.STANDBY
        else -> busy
    }

    private fun updateUi() {
        val st = effectiveState()
        orb.state = st
        statusView.text = "\u25CF " + st.status
        statusView.setTextColor(st.color)
        statusView.background = GradientDrawable().apply {
            cornerRadius = dp(22).toFloat()
            setColor((st.color and 0x00FFFFFF) or 0x22000000)
            setStroke(dp(1), st.color)
        }
        orbLabel.text = st.orbLabel
        orbLabel.setTextColor(st.color)
        val shown = errorMessage ?: hint ?: ""
        hintView.text = shown
        hintView.setTextColor(if (errorMessage != null) Palette.ORANGE else Palette.TEXT)
        hintCard.visibility = if (shown.isEmpty()) View.INVISIBLE else View.VISIBLE
        hintCard.post { hintCard.fullScroll(View.FOCUS_DOWN) }
        modeView.text = "MODE  \u2022  " + currentMode.label

        val led = when {
            !powerOn -> Palette.GREY
            muted -> Palette.RED
            st == AssistantState.LISTENING -> Palette.GREEN
            else -> Palette.YELLOW
        }
        (micLed.background as GradientDrawable).setColor(led)
        micControl.icon.setColorFilter(if (muted) Palette.RED else Palette.CYAN)
        powerControl.icon.setColorFilter(if (powerOn) Palette.GREEN else Palette.GREY)

        for ((m, v) in modeRows) {
            val sel = m == currentMode
            v.background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(if (sel) 0x3300E5FF else 0x11FFFFFF)
                setStroke(dp(1), if (sel) Palette.CYAN else 0x22FFFFFF)
            }
        }
    }

    // ------------------------------------------------------------ user actions

    private fun onMicTapped() {
        if (!powerOn) {
            hint = "JARVIS is powered off. Tap the power button first."
            updateUi()
            return
        }
        if (errorMessage != null) {            // retry after a failure
            errorMessage = null
            hint = null
            if (!micGranted()) micPermission.launch(Manifest.permission.RECORD_AUDIO)
            else startListeningIfAllowed()
            updateUi()
            return
        }
        muted = !muted
        if (muted) {
            voice.stopListening()
            hint = "Microphone muted. JARVIS cannot hear you."
        } else {
            hint = null
            if (!micGranted()) micPermission.launch(Manifest.permission.RECORD_AUDIO)
            else startListeningIfAllowed()
        }
        updateUi()
    }

    private fun onPowerTapped() {
        if (powerOn) powerOff() else powerOnNow()
    }

    private fun powerOnNow() {
        powerOn = true
        errorMessage = null
        hint = null
        speakThen(Greetings.POWER_ON, null)
        updateUi()
    }

    private fun startListeningIfAllowed() {
        if (!resumed || !voiceReady || !powerOn || muted || errorMessage != null) return
        if (busy == AssistantState.SPEAKING || busy == AssistantState.THINKING) return
        if (!micGranted()) return
        voice.startListening()
    }

    private fun speakThen(text: String, after: (() -> Unit)?) {
        pendingAfter = after
        hint = (hint?.takeIf { it.startsWith("You:") }?.plus("\n") ?: "") + "JARVIS: " + text
        busy = AssistantState.THINKING
        updateUi()
        voice.speak(text)
    }

    // ------------------------------------------------------------ camera vision

    private fun onCameraTapped() {
        if (!powerOn) {
            hint = "JARVIS is powered off. Tap the power button first."
            updateUi()
            return
        }
        if (!brain.hasProvider()) {
            hint = "Camera vision needs an AI provider that understands images, for example Google Gemini. " +
                "Add a key in Settings > AI Models & Networks."
            updateUi()
            return
        }
        try {
            val dir = File(cacheDir, "shots")
            dir.mkdirs()
            val f = File(dir, "shot.jpg")
            if (!f.exists()) f.createNewFile()
            photoFile = f
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            voice.stopListening()
            takePicture.launch(uri)
        } catch (e: Exception) {
            hint = "Could not open the camera app on this phone."
            updateUi()
        }
    }

    private fun loadBitmap(f: File, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bm = BitmapFactory.decodeFile(f.path, opts) ?: return null
        val rotation = try {
            when (ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                6 -> 90f
                3 -> 180f
                8 -> 270f
                else -> 0f
            }
        } catch (e: Exception) {
            0f
        }
        val longest = maxOf(bm.width, bm.height).toFloat()
        val scale = if (longest > maxSide) maxSide / longest else 1f
        if (rotation == 0f && scale == 1f) return bm
        val m = Matrix()
        m.postRotate(rotation)
        m.postScale(scale, scale)
        return Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, m, true)
    }

    private fun showPhotoDialog(f: File) {
        val bmp = loadBitmap(f, 1280)
        if (bmp == null) {
            hint = "Could not read the photo."
            updateUi()
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), 0)
        }
        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            adjustViewBounds = true
            maxHeight = dp(280)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        box.addView(iv, LinearLayout.LayoutParams(MATCH, WRAP))
        val q = EditText(this).apply {
            setText("What do you see? Describe it briefly.")
            maxLines = 3
        }
        box.addView(q, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        AlertDialog.Builder(this)
            .setTitle("Ask JARVIS about this photo")
            .setView(box)
            .setPositiveButton("Ask JARVIS") { _, _ ->
                val question = q.text.toString().trim().ifEmpty { "Describe this image." }
                sendPhoto(bmp, question)
            }
            .setNegativeButton("Cancel", null)
            .setOnDismissListener { startListeningIfAllowed() }
            .show()
    }

    private fun sendPhoto(bmp: Bitmap, question: String) {
        val token = ++aiToken
        busy = AssistantState.THINKING
        hint = "You: [photo] $question"
        updateUi()
        val mode = currentMode
        Thread {
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 80, bos)
            val r = brain.askWithImage(question, bos.toByteArray(), mode)
            runOnUiThread { deliverAi(token, r) }
        }.start()
    }

    // ------------------------------------------------------------ AI

    private fun deliverAi(token: Int, r: AiResult) {
        if (token != aiToken || !powerOn || isFinishing) return
        if (r.text != null) {
            speakThen(forSpeech(r.text), null)
        } else {
            speakThen("Sorry Sir, I could not get an answer from the AI.", null)
            hint = (hint ?: "") + "\nAI error: " + (r.error ?: "unknown")
            updateUi()
        }
    }

    private fun askAi(text: String) {
        if (!brain.hasProvider()) {
            speakThen(
                "AI is not connected yet, Sir. Open Settings, then AI Models and Networks, and add a free Gemini key.",
                null
            )
            return
        }
        val token = ++aiToken
        busy = AssistantState.THINKING
        hint = "You: $text"
        updateUi()
        val mode = currentMode
        Thread {
            val r = brain.ask(text, mode)
            runOnUiThread { deliverAi(token, r) }
        }.start()
    }

    private fun forSpeech(t: String): String =
        t.replace(Regex("[*_`#>]"), "").replace(Regex("\\s+"), " ").trim().take(900)

    // ------------------------------------------------------------ VoiceEngine.Listener

    override fun onHeard(text: String) {
        busy = AssistantState.THINKING
        hint = "You: $text"
        updateUi()
        val reply = CommandRouter.handle(text, this)
        if (reply != null) {
            speakThen(reply.text, reply.after)
        } else {
            askAi(text)
        }
    }

    override fun onListeningStarted() {
        if (busy != AssistantState.SPEAKING && busy != AssistantState.THINKING) {
            busy = AssistantState.LISTENING
            updateUi()
        }
    }

    override fun onVoiceError(message: String, fatal: Boolean) {
        if (fatal) errorMessage = message else hint = message
        updateUi()
    }

    override fun onSpeakStart() {
        busy = AssistantState.SPEAKING
        updateUi()
    }

    override fun onSpeakDone() {
        busy = AssistantState.READY
        val after = pendingAfter
        pendingAfter = null
        after?.invoke()
        startListeningIfAllowed()
        updateUi()
    }

    // ------------------------------------------------------------ CommandRouter.Host

    override fun switchMode(mode: AssistantMode) {
        prefs.mode = mode.name
        updateUi()
    }

    override fun muteMic() {
        muted = true
        voice.stopListening()
        updateUi()
    }

    override fun powerOff() {
        powerOn = false
        aiToken++
        pendingAfter = null
        voice.stopListening()
        voice.stopSpeaking()
        busy = AssistantState.READY
        errorMessage = null
        hint = "JARVIS is powered off. Listening has stopped."
        updateUi()
    }

    override fun openUrl(url: String): Boolean = try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    override fun openCamera() = onCameraTapped()

    override fun say(text: String) = speakThen(text, null)
}
