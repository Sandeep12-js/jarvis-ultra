package com.sandeep.jarvis

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View

/** Static HUD backdrop: soft glow behind the core, faint grid and corner brackets. */
class HudBackground(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density

        // Soft glow behind the orb
        paint.shader = RadialGradient(
            w / 2f, h * 0.42f, w * 0.95f,
            intArrayOf(0x55103A5C, 0x22081C2E, 0x00000000),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        // Faint grid
        line.strokeWidth = 1f
        line.color = 0x0D00E5FF
        val step = 36f * d
        var x = 0f
        while (x < w) { canvas.drawLine(x, 0f, x, h, line); x += step }
        var y = 0f
        while (y < h) { canvas.drawLine(0f, y, w, y, line); y += step }

        // Corner brackets
        line.strokeWidth = 2f * d
        line.strokeCap = Paint.Cap.ROUND
        line.color = 0x9900E5FF.toInt()
        val m = 14f * d
        val l = 28f * d
        canvas.drawLine(m, m, m + l, m, line); canvas.drawLine(m, m, m, m + l, line)
        canvas.drawLine(w - m, m, w - m - l, m, line); canvas.drawLine(w - m, m, w - m, m + l, line)
        canvas.drawLine(m, h - m, m + l, h - m, line); canvas.drawLine(m, h - m, m, h - m - l, line)
        canvas.drawLine(w - m, h - m, w - m - l, h - m, line); canvas.drawLine(w - m, h - m, w - m, h - m - l, line)
    }
}
