package com.sandeep.jarvis

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * JARVIS-style HUD energy core: glowing core, rotating tick ring, segmented rings,
 * and a ring of reactive bars. Animation changes with the assistant state.
 */
class OrbView(context: Context) : View(context) {

    var state: AssistantState = AssistantState.READY
        set(value) {
            field = value
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()
    private val rnd = Random(11)
    private val pCount = 22
    private val pAngle = FloatArray(pCount) { rnd.nextFloat() * 6.2831855f }
    private val pRadius = FloatArray(pCount) { 0.34f + rnd.nextFloat() * 0.5f }
    private val pSize = FloatArray(pCount) { 1.2f + rnd.nextFloat() * 2.4f }
    private val pSpeed = FloatArray(pCount) {
        (0.2f + rnd.nextFloat() * 0.8f) * (if (rnd.nextBoolean()) 1f else -1f)
    }

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    private fun a(color: Int, alpha: Int): Int =
        (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) / 2f
        val d = resources.displayMetrics.density
        val sec = (SystemClock.uptimeMillis() % 3_600_000L) / 1000f
        val c = state.color
        val deg2rad = 0.017453292f

        // amp = breathing size, speed = rotation/pulse speed, bars = height of the reactive bars
        val amp: Float
        val speed: Float
        val bars: Float
        when (state) {
            AssistantState.READY -> { amp = 0.03f; speed = 1.0f; bars = 0.30f }
            AssistantState.LISTENING -> { amp = 0.06f; speed = 2.5f; bars = 1.00f }
            AssistantState.THINKING -> { amp = 0.04f; speed = 6.0f; bars = 0.70f }
            AssistantState.SPEAKING -> { amp = 0.08f; speed = 3.5f; bars = 1.40f }
            AssistantState.STANDBY -> { amp = 0.02f; speed = 0.5f; bars = 0.15f }
            AssistantState.MUTED -> { amp = 0.015f; speed = 0.3f; bars = 0.08f }
            AssistantState.OFFLINE -> { amp = 0f; speed = 0f; bars = 0f }
            AssistantState.ERROR -> { amp = 0.05f; speed = 8.0f; bars = 0.80f }
        }
        val dim = if (state == AssistantState.OFFLINE) 0.25f else 1f
        var breath = 1f + amp * sin(sec * 3.1415927f * speed)
        if (state == AssistantState.SPEAKING) breath += amp * 0.6f * sin(sec * 13f)

        // 1. Outer glow
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx, cy, base,
            intArrayOf(a(c, (90 * dim).toInt()), a(c, (30 * dim).toInt()), a(c, 0)),
            floatArrayOf(0.2f, 0.65f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, base, paint)
        paint.shader = null

        // 2. Rotating tick ring
        ring.strokeWidth = d * 1.3f
        ring.color = a(c, (170 * dim).toInt())
        val tickR = base * 0.97f
        val rot0 = sec * 6f * speed
        for (i in 0 until 72) {
            val ang = (i * 5f + rot0) * deg2rad
            val len = if (i % 6 == 0) base * 0.075f else base * 0.035f
            canvas.drawLine(
                cx + cos(ang) * tickR, cy + sin(ang) * tickR,
                cx + cos(ang) * (tickR - len), cy + sin(ang) * (tickR - len), ring
            )
        }

        // 3. Segmented ring (12 dashes), rotating one way
        ring.strokeWidth = d * 2.2f
        ring.color = a(c, (200 * dim).toInt())
        var rr = base * 0.84f
        rect.set(cx - rr, cy - rr, cx + rr, cy + rr)
        val rotA = sec * 18f * speed
        for (k in 0 until 12) canvas.drawArc(rect, k * 30f + rotA, 20f, false, ring)

        // 4. Three thick arcs, rotating the other way
        ring.strokeWidth = d * 4f
        ring.color = a(Palette.BLUE, (230 * dim).toInt())
        rr = base * 0.73f
        rect.set(cx - rr, cy - rr, cx + rr, cy + rr)
        val rotB = -sec * 30f * speed
        for (k in 0 until 3) canvas.drawArc(rect, k * 120f + rotB, 70f, false, ring)

        // 5. Thin full circle
        ring.strokeWidth = d * 1f
        ring.color = a(c, (110 * dim).toInt())
        canvas.drawCircle(cx, cy, base * 0.64f, ring)

        // 6. Reactive bars around the core
        ring.strokeWidth = d * 2.4f
        ring.color = a(c, (230 * dim).toInt())
        val inner = base * 0.44f
        for (i in 0 until 48) {
            val ang = i * 7.5f * deg2rad
            val wave = 0.5f + 0.5f * sin(sec * (3f + speed) + i * 0.9f) * sin(sec * 1.7f + i * 0.37f)
            val len = base * (0.025f + 0.11f * bars * wave)
            canvas.drawLine(
                cx + cos(ang) * inner, cy + sin(ang) * inner,
                cx + cos(ang) * (inner + len), cy + sin(ang) * (inner + len), ring
            )
        }

        // 7. Glowing core
        val r = base * 0.30f * breath
        paint.shader = RadialGradient(
            cx, cy, r * 1.5f,
            intArrayOf(
                a(Color.WHITE, (255 * dim).toInt()),
                a(c, (240 * dim).toInt()),
                a(Palette.BLUE, (110 * dim).toInt()),
                a(Palette.BLUE, 0)
            ),
            floatArrayOf(0f, 0.45f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r * 1.5f, paint)
        paint.shader = null
        ring.strokeWidth = d * 1.5f
        ring.color = a(Color.WHITE, (200 * dim).toInt())
        canvas.drawCircle(cx, cy, r * 0.62f, ring)

        // 8. Particles
        for (i in 0 until pCount) {
            val ang = pAngle[i] + sec * pSpeed[i] * (0.3f + 0.3f * speed)
            val rad = base * pRadius[i]
            val tw = 0.5f + 0.5f * sin(sec * 2f + i)
            paint.color = a(if (i % 5 == 0) Palette.PURPLE else c, ((50 + 170 * tw) * dim).toInt())
            canvas.drawCircle(cx + cos(ang) * rad, cy + sin(ang) * rad, pSize[i] * d * 0.6f, paint)
        }
    }
}
