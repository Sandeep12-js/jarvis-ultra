package com.sandeep.jarvis

/** In-memory conversation log (cleared when the app process ends) and a hand-off for typed messages. */
object Conversation {
    private val lines = ArrayList<String>()

    /** A message typed in Settings; MainActivity picks it up and answers it. */
    @Volatile
    var pendingInput: String? = null

    @Synchronized
    fun add(who: String, text: String) {
        lines.add("$who: $text")
        while (lines.size > 200) lines.removeAt(0)
    }

    @Synchronized
    fun all(): List<String> = ArrayList(lines)

    @Synchronized
    fun clear() {
        lines.clear()
    }
}
