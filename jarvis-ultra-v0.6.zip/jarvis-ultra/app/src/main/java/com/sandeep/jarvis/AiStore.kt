package com.sandeep.jarvis

import android.content.Context

enum class ProviderKind { GEMINI, OPENAI }

class ProviderDef(
    val id: String,
    val title: String,
    val kind: ProviderKind,
    val defaultBase: String,
    val defaultModel: String,
    val costNote: String,
    val keyHelp: String
)

/** Order here = fallback order. Free-first providers come first. */
object Providers {
    val all = listOf(
        ProviderDef(
            "gemini", "Google Gemini", ProviderKind.GEMINI,
            "https://generativelanguage.googleapis.com", "gemini-3.8-flash",
            "Free tier available (rate-limited, no billing needed). Google may use free-tier data to improve its products.",
            "Get a free key: aistudio.google.com/apikey"
        ),
        ProviderDef(
            "groq", "Groq", ProviderKind.OPENAI,
            "https://api.groq.com/openai/v1", "openai/gpt-oss-120b",
            "Free tier, no card needed (about 30 requests/min). Has a vision model too.",
            "Get a key: console.groq.com/keys"
        ),
        ProviderDef(
            "openrouter", "OpenRouter", ProviderKind.OPENAI,
            "https://openrouter.ai/api/v1", "openrouter/free",
            "Some models are free (names end with :free). Tap 'Fetch models' to see only the free ones.",
            "Get a key: openrouter.ai/keys"
        ),
        ProviderDef(
            "deepseek", "DeepSeek", ProviderKind.OPENAI,
            "https://api.deepseek.com", "deepseek-chat",
            "Usually PAID per use. Keep it disabled unless you want that.",
            "Get a key: platform.deepseek.com"
        ),
        ProviderDef(
            "custom", "Custom (OpenAI-compatible)", ProviderKind.OPENAI,
            "", "",
            "Cost depends on the provider you enter.",
            "Enter a https address (usually ending in /v1), model and key."
        )
    )
}

class ProviderConfig(val enabled: Boolean, val key: String, val model: String, val base: String)

class AiStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jarvis_ai", Context.MODE_PRIVATE)

    fun config(def: ProviderDef): ProviderConfig {
        val enc = sp.getString("${def.id}_key", null)
        val key = if (enc.isNullOrEmpty()) "" else (SecureStore.decrypt(enc) ?: "")
        return ProviderConfig(
            enabled = sp.getBoolean("${def.id}_enabled", false),
            key = key,
            model = sp.getString("${def.id}_model", def.defaultModel) ?: def.defaultModel,
            base = sp.getString("${def.id}_base", def.defaultBase) ?: def.defaultBase
        )
    }

    fun hasKey(def: ProviderDef): Boolean = !sp.getString("${def.id}_key", null).isNullOrEmpty()

    /** newKey == null keeps the saved key; "" is treated the same (keep). */
    fun save(def: ProviderDef, enabled: Boolean, newKey: String?, model: String, base: String) {
        val e = sp.edit()
        e.putBoolean("${def.id}_enabled", enabled)
        e.putString("${def.id}_model", model.trim())
        e.putString("${def.id}_base", base.trim())
        if (!newKey.isNullOrBlank()) e.putString("${def.id}_key", SecureStore.encrypt(newKey.trim()))
        e.apply()
    }

    fun setModel(def: ProviderDef, model: String) {
        sp.edit().putString("${def.id}_model", model).apply()
    }

    fun removeKey(def: ProviderDef) {
        sp.edit().remove("${def.id}_key").putBoolean("${def.id}_enabled", false).apply()
    }

    fun isUsable(def: ProviderDef): Boolean {
        val c = config(def)
        if (!c.enabled || c.key.isBlank() || c.model.isBlank()) return false
        if (def.kind == ProviderKind.OPENAI && !c.base.startsWith("https://")) return false
        return true
    }

    fun usableCount(): Int = Providers.all.count { isUsable(it) }
}
