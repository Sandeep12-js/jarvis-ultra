package com.sandeep.jarvis

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

class AiException(message: String, val code: Int = 0) : Exception(message)

/** Real HTTPS calls to AI providers. Blocking: call from a background thread. */
object AiClient {

    fun chat(
        def: ProviderDef,
        cfg: ProviderConfig,
        system: String,
        history: List<Pair<String, String>>,
        user: String
    ): String {
        val all = history + (("user") to user)
        return if (def.kind == ProviderKind.GEMINI) geminiChat(cfg, system, all)
        else openAiChat(cfg, system, all)
    }

    /** Ask a question about one JPEG photo. Needs a vision-capable model. */
    fun chatImage(def: ProviderDef, cfg: ProviderConfig, system: String, question: String, jpeg: ByteArray): String {
        val b64 = android.util.Base64.encodeToString(jpeg, android.util.Base64.NO_WRAP)
        return if (def.kind == ProviderKind.GEMINI) {
            val parts = JSONArray()
                .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", b64)))
                .put(JSONObject().put("text", question))
            val contents = JSONArray().put(JSONObject().put("role", "user").put("parts", parts))
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("maxOutputTokens", 2048))
            val model = cfg.model.trim().removePrefix("models/")
            val url = cfg.base.trimEnd('/') + "/v1beta/models/" + model + ":generateContent"
            parseGemini(http("POST", url, mapOf("x-goog-api-key" to cfg.key), body.toString()))
        } else {
            val content = JSONArray()
                .put(JSONObject().put("type", "text").put("text", question))
                .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64")))
            val messages = JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", content))
            val body = JSONObject().put("model", cfg.model.trim()).put("messages", messages).put("max_tokens", 1500)
            val url = cfg.base.trimEnd('/') + "/chat/completions"
            parseOpenAi(http("POST", url, mapOf("Authorization" to "Bearer " + cfg.key), body.toString()))
        }
    }

    fun listModels(def: ProviderDef, cfg: ProviderConfig): List<String> {
        return if (def.kind == ProviderKind.GEMINI) {
            val body = http(
                "GET", cfg.base.trimEnd('/') + "/v1beta/models?pageSize=100",
                mapOf("x-goog-api-key" to cfg.key), null
            )
            val arr = JSONObject(body).optJSONArray("models") ?: JSONArray()
            val out = ArrayList<String>()
            for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                val methods = m.optJSONArray("supportedGenerationMethods")
                var ok = false
                if (methods != null) for (j in 0 until methods.length()) {
                    if (methods.getString(j) == "generateContent") ok = true
                }
                if (ok) out.add(m.getString("name").removePrefix("models/"))
            }
            out.sorted()
        } else {
            val body = http(
                "GET", cfg.base.trimEnd('/') + "/models",
                mapOf("Authorization" to "Bearer " + cfg.key), null
            )
            val arr = JSONObject(body).optJSONArray("data") ?: JSONArray()
            val out = ArrayList<String>()
            for (i in 0 until arr.length()) out.add(arr.getJSONObject(i).getString("id"))
            val filtered = if (def.id == "openrouter") out.filter { it.endsWith(":free") } else out
            filtered.sorted().take(80)
        }
    }

    // ---------------- Gemini ----------------

    private fun geminiChat(cfg: ProviderConfig, system: String, msgs: List<Pair<String, String>>): String {
        val contents = JSONArray()
        for ((role, text) in msgs) {
            contents.put(
                JSONObject()
                    .put("role", if (role == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("maxOutputTokens", 2048))
        val model = cfg.model.trim().removePrefix("models/")
        val url = cfg.base.trimEnd('/') + "/v1beta/models/" + model + ":generateContent"
        return parseGemini(http("POST", url, mapOf("x-goog-api-key" to cfg.key), body.toString()))
    }

    private fun parseGemini(resp: String): String {
        val cands = JSONObject(resp).optJSONArray("candidates")
        if (cands == null || cands.length() == 0) throw AiException("Gemini gave no answer (it may have been blocked).")
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        val text = sb.toString().trim()
        if (text.isEmpty()) throw AiException("Gemini returned an empty answer.")
        return text
    }

    // ---------------- OpenAI-compatible ----------------

    private fun openAiChat(cfg: ProviderConfig, system: String, msgs: List<Pair<String, String>>): String {
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", system))
        for ((role, text) in msgs) {
            messages.put(JSONObject().put("role", if (role == "user") "user" else "assistant").put("content", text))
        }
        val body = JSONObject()
            .put("model", cfg.model.trim())
            .put("messages", messages)
            .put("max_tokens", 1500)
        val url = cfg.base.trimEnd('/') + "/chat/completions"
        return parseOpenAi(http("POST", url, mapOf("Authorization" to "Bearer " + cfg.key), body.toString()))
    }

    private fun parseOpenAi(resp: String): String {
        val choices = JSONObject(resp).optJSONArray("choices")
        if (choices == null || choices.length() == 0) throw AiException("The provider gave no answer.")
        val text = choices.getJSONObject(0).optJSONObject("message")?.optString("content", "")?.trim() ?: ""
        if (text.isEmpty()) throw AiException("The provider returned an empty answer.")
        return text
    }

    // ---------------- HTTP ----------------

    private fun http(method: String, url: String, headers: Map<String, String>, body: String?): String {
        if (!url.startsWith("https://")) throw AiException("Only secure https:// addresses are allowed.")
        val conn = try {
            URL(url).openConnection() as HttpURLConnection
        } catch (e: Exception) {
            throw AiException("The server address is not valid.")
        }
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15000
            conn.readTimeout = 45000
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw AiException(describeError(code, text), code)
            return text
        } catch (e: AiException) {
            throw e
        } catch (e: UnknownHostException) {
            throw AiException("No internet connection.")
        } catch (e: SocketTimeoutException) {
            throw AiException("The AI server took too long to answer.")
        } catch (e: Exception) {
            throw AiException("Network error (" + e.javaClass.simpleName + ").")
        } finally {
            conn.disconnect()
        }
    }

    private fun describeError(code: Int, body: String): String {
        val detail = try {
            val j = JSONObject(body)
            val err = j.opt("error")
            when (err) {
                is JSONObject -> err.optString("message", "")
                is String -> err
                else -> ""
            }
        } catch (e: Exception) {
            ""
        }.take(160)
        val head = when (code) {
            400 -> "Request rejected (400)"
            401, 403 -> "API key rejected or not allowed ($code)"
            404 -> "Model or address not found (404). Check the model name"
            429 -> "Free quota or rate limit of this model is used up (429)"
            in 500..599 -> "Provider is busy or down ($code)"
            else -> "HTTP error $code"
        }
        return if (detail.isEmpty()) head else "$head: $detail"
    }
}
