package com.sandeep.jarvis

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import java.io.ByteArrayOutputStream

/**
 * Screen sharing. Runs as a visible foreground service (notification + Android's own
 * screen-sharing indicator). While it runs, JARVIS keeps listening and, when you ask something,
 * looks at the latest screen picture and answers by voice. Nothing is captured unless you
 * approved Android's screen-capture dialog, and STOP ends everything.
 */
class ScreenAssistService : Service(), VoiceEngine.Listener {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "jarvis_screen"
        private const val NOTIF_ID = 4711

        @Volatile
        var running = false

        /** Called on the main thread whenever sharing starts or stops. */
        var onStateChanged: (() -> Unit)? = null
    }

    private lateinit var prefs: Prefs
    private lateinit var brain: AiBrain
    private var voice: VoiceEngine? = null

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val frameThread = HandlerThread("jarvis-frames")
    private lateinit var frameHandler: Handler
    private val main = Handler(Looper.getMainLooper())

    private val frameLock = Any()
    private var lastFrame: Bitmap? = null
    private var lastConvert = 0L
    private var token = 0
    private var stopped = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        brain = AiBrain(this)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "JARVIS screen sharing", NotificationManager.IMPORTANCE_LOW)
        )
        frameThread.start()
        frameHandler = Handler(frameThread.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            if (running) stopSharing() else stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY
        val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = intent?.let { IntentCompat.getParcelableExtra(it, EXTRA_DATA, Intent::class.java) }
        if (data == null || code != Activity.RESULT_OK) {
            failStart()
            return START_NOT_STICKY
        }
        try {
            startForegroundCompat("Starting screen sharing...")
        } catch (e: Exception) {
            failStart()
            return START_NOT_STICKY
        }
        try {
            startProjection(code, data)
        } catch (e: Exception) {
            failStart()
            return START_NOT_STICKY
        }
        running = true
        onStateChanged?.invoke()
        val v = VoiceEngine(this, prefs, this)
        voice = v
        v.init {
            v.refreshVoice()
            v.speak("Screen sharing is on, Sir. Open any app and ask me about your screen.")
        }
        return START_NOT_STICKY
    }

    private fun failStart() {
        stopped = true
        running = false
        onStateChanged?.invoke()
        stopSelf()
    }

    private fun startForegroundCompat(text: String) {
        val type = when {
            Build.VERSION.SDK_INT >= 30 ->
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            Build.VERSION.SDK_INT >= 29 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            else -> 0
        }
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(text), type)
    }

    private fun buildNotification(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ScreenAssistService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_screen)
            .setContentTitle("JARVIS is sharing your screen")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, "STOP", stop)
            .build()
    }

    private fun updateNotification(text: String) {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildNotification(text))
        } catch (e: Exception) {
            // notification is only a status display
        }
    }

    private fun startProjection(code: Int, data: Intent) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        projection = p
        val cb = object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSharing() }
            }
        }
        projectionCallback = cb
        p.registerCallback(cb, main)

        val dm = resources.displayMetrics
        var w = dm.widthPixels
        var h = dm.heightPixels
        val longest = maxOf(w, h)
        if (longest > 1280) {
            val s = 1280f / longest
            w = (w * s).toInt()
            h = (h * s).toInt()
        }
        w = maxOf(w, 2)
        h = maxOf(h, 2)
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader = r
        r.setOnImageAvailableListener({ rd -> onFrame(rd) }, frameHandler)
        display = p.createVirtualDisplay(
            "jarvis-screen", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    private fun onFrame(rd: ImageReader) {
        var img: Image? = null
        try {
            img = rd.acquireLatestImage() ?: return
            val now = SystemClock.uptimeMillis()
            if (now - lastConvert < 400 && lastFrame != null) return
            lastConvert = now
            val plane = img.planes[0]
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * img.width
            val wide = Bitmap.createBitmap(img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888)
            wide.copyPixelsFromBuffer(plane.buffer)
            val cropped = Bitmap.createBitmap(wide, 0, 0, img.width, img.height)
            synchronized(frameLock) { lastFrame = cropped }
        } catch (e: Exception) {
            // skip this frame
        } finally {
            img?.close()
        }
    }

    // ---------------- voice ----------------

    override fun onHeard(text: String) {
        val t = text.lowercase()
        if (Regex("stop (sharing|screen|share)|screen (band|stop)|stop jarvis").containsMatchIn(t)) {
            voice?.speak("Stopping screen sharing, Sir.")
            main.postDelayed({ stopSharing() }, 2500)
            return
        }
        val frame = synchronized(frameLock) { lastFrame }
        if (frame == null) {
            voice?.speak("I cannot see the screen yet, Sir. Please try again.")
            return
        }
        val my = ++token
        updateNotification("You: $text\nLooking at your screen...")
        val mode = AssistantMode.fromName(prefs.mode)
        Thread {
            val bos = ByteArrayOutputStream()
            frame.compress(Bitmap.CompressFormat.JPEG, 75, bos)
            val r = brain.askWithImage(text, bos.toByteArray(), mode, "screen")
            main.post {
                if (my != token || !running) return@post
                val answer = r.text
                if (answer != null) {
                    val clean = answer.replace(Regex("[*_`#>]"), "").replace(Regex("\\s+"), " ").trim().take(900)
                    updateNotification("You: $text\nJARVIS: $clean")
                    voice?.speak(clean)
                } else {
                    updateNotification("AI error: " + (r.error ?: "unknown"))
                    voice?.speak("Sorry Sir, I could not get an answer from the AI.")
                }
            }
        }.start()
    }

    override fun onListeningStarted() {}

    override fun onVoiceError(message: String, fatal: Boolean) {
        updateNotification(message)
    }

    override fun onSpeakStart() {}

    override fun onSpeakDone() {
        if (running) voice?.startListening()
    }

    // ---------------- stopping ----------------

    private fun stopSharing() {
        if (stopped) return
        stopped = true
        token++
        running = false
        try { voice?.destroy() } catch (e: Exception) { }
        voice = null
        try { display?.release() } catch (e: Exception) { }
        display = null
        try { reader?.close() } catch (e: Exception) { }
        reader = null
        try {
            projectionCallback?.let { projection?.unregisterCallback(it) }
            projection?.stop()
        } catch (e: Exception) { }
        projection = null
        synchronized(frameLock) { lastFrame = null }
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
        stopSelf()
        onStateChanged?.invoke()
    }

    override fun onDestroy() {
        stopSharing()
        frameThread.quitSafely()
        super.onDestroy()
    }
}
