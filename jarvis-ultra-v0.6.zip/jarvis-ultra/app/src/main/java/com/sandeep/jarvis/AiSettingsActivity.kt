package com.sandeep.jarvis

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

class AiSettingsActivity : AppCompatActivity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private lateinit var store: AiStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        store = AiStore(this)
        build()
    }

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(TextView(this).apply {
            text = "\u2190"
            textSize = 26f
            setTextColor(Palette.CYAN)
            gravity = Gravity.CENTER
            contentDescription = "Back"
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(56), dp(56)))
        bar.addView(TextView(this).apply {
            text = "AI & INTELLIGENCE"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
            setTextColor(Palette.CYAN)
        })
        root.addView(bar, LinearLayout.LayoutParams(MATCH, dp(56)))

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(32))
        }
        list.addView(TextView(this).apply {
            text = "JARVIS tries the enabled providers from top to bottom and uses the first one that answers. " +
                "If a model is gone or its free quota is used up, JARVIS automatically tries other real models from the provider's own list. " +
                "Best setup: turn ON both Gemini and Groq, so one covers the other. " +
                "Nothing is used unless you turn it ON and enter your own key. Keys are stored encrypted on this phone only."
            textSize = 13f
            setTextColor(Palette.SUBTEXT)
        })
        for (def in Providers.all) list.addView(providerCard(def))

        val scroll = ScrollView(this)
        scroll.isFillViewport = false
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val frame = android.widget.FrameLayout(this).apply { setBackgroundColor(Palette.BG) }
        frame.addView(HudBackground(this), ViewGroup.LayoutParams(MATCH, MATCH))
        frame.addView(root, ViewGroup.LayoutParams(MATCH, MATCH))
        setContentView(frame)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
    }

    private fun providerCard(def: ProviderDef): View {
        val cfg = store.config(def)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Palette.PANEL)
                setStroke(dp(1), 0x3300E5FF)
            }
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }
        }
        card.addView(label(def.title, 16f, Palette.CYAN, true))
        card.addView(label(def.costNote, 12f, Palette.YELLOW, false))
        card.addView(label(def.keyHelp, 12f, Palette.SUBTEXT, false))

        val sw = SwitchCompat(this).apply {
            text = "Enabled"
            isChecked = cfg.enabled
            setTextColor(Palette.TEXT)
        }
        card.addView(sw, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        val keyField = field(
            if (store.hasKey(def)) "API key saved (type a new one to replace)" else "Paste API key here",
            "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        )
        card.addView(keyField)

        val modelField = field("Model name", cfg.model, InputType.TYPE_CLASS_TEXT)
        card.addView(modelField)

        var baseField: EditText? = null
        if (def.kind == ProviderKind.OPENAI) {
            baseField = field("Server address (https://...)", cfg.base, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
            card.addView(baseField)
        }

        val status = label("", 13f, Palette.TEXT, false)

        fun saveNow(): Boolean {
            val base = baseField?.text?.toString()?.trim() ?: def.defaultBase
            if (def.kind == ProviderKind.OPENAI && base.isNotEmpty() && !base.startsWith("https://")) {
                status.text = "Address must start with https://"
                status.setTextColor(Palette.ORANGE)
                return false
            }
            store.save(def, sw.isChecked, keyField.text.toString(), modelField.text.toString(), base)
            keyField.setText("")
            keyField.hint = if (store.hasKey(def)) "API key saved (type a new one to replace)" else "Paste API key here"
            return true
        }

        card.addView(button("Save") {
            if (saveNow()) {
                status.text = "Saved."
                status.setTextColor(Palette.GREEN)
            }
        })
        card.addView(button("Test connection") {
            if (!saveNow()) return@button
            val c = store.config(def)
            if (c.key.isBlank()) { status.text = "Enter an API key first."; status.setTextColor(Palette.ORANGE); return@button }
            if (c.model.isBlank()) { status.text = "Enter a model name (or use Fetch models)."; status.setTextColor(Palette.ORANGE); return@button }
            status.text = "Testing..."
            status.setTextColor(Palette.SUBTEXT)
            Thread {
                var msg = ""
                var ok = false
                try {
                    val r = AiClient.chat(def, c, "You are a connection test. Reply in at most six words.", emptyList(), "Say hello.")
                    msg = "Working. Reply: " + r.take(80)
                    ok = true
                } catch (e: AiException) {
                    msg = "Failed: " + e.message
                    ok = false
                } catch (e: Exception) {
                    msg = "Failed: unexpected error"
                    ok = false
                }
                runOnUiThread {
                    status.text = msg
                    status.setTextColor(if (ok) Palette.GREEN else Palette.ORANGE)
                }
            }.start()
        })
        card.addView(button("Auto-pick a working model & test") {
            if (!saveNow()) return@button
            val c = store.config(def)
            if (c.key.isBlank()) { status.text = "Enter an API key first."; status.setTextColor(Palette.ORANGE); return@button }
            status.text = "Finding a working model..."
            status.setTextColor(Palette.SUBTEXT)
            Thread {
                var chosen: String? = null
                var msg = ""
                var ok = false
                try {
                    val ids = AiClient.listModels(def, c)
                    val cands = ModelPicker.candidates(def, ids, false).take(4)
                    if (cands.isEmpty()) {
                        msg = "No usable models found for this key."
                    } else {
                        var lastErr = ""
                        for (m in cands) {
                            try {
                                val r = AiClient.chat(
                                    def, ProviderConfig(true, c.key, m, c.base),
                                    "Reply in at most six words.", emptyList(), "Say hello."
                                )
                                chosen = m
                                msg = "Working with $m. Reply: " + r.take(60)
                                ok = true
                                break
                            } catch (e: AiException) {
                                lastErr = m + ": " + e.message
                            }
                        }
                        if (!ok) msg = "None of the models worked. Last error: $lastErr"
                    }
                } catch (e: AiException) {
                    msg = "Failed: " + e.message
                } catch (e: Exception) {
                    msg = "Failed: unexpected error"
                }
                val picked = chosen
                runOnUiThread {
                    status.text = msg
                    status.setTextColor(if (ok) Palette.GREEN else Palette.ORANGE)
                    if (picked != null) {
                        modelField.setText(picked)
                        store.save(def, sw.isChecked, null, picked, baseField?.text?.toString() ?: def.defaultBase)
                    }
                }
            }.start()
        })
        card.addView(button("Fetch models") {
            if (!saveNow()) return@button
            val c = store.config(def)
            if (c.key.isBlank()) { status.text = "Enter an API key first."; status.setTextColor(Palette.ORANGE); return@button }
            status.text = "Fetching models..."
            status.setTextColor(Palette.SUBTEXT)
            Thread {
                var models: List<String> = emptyList()
                var err: String? = null
                try {
                    models = AiClient.listModels(def, c)
                } catch (e: AiException) {
                    err = e.message
                } catch (e: Exception) {
                    err = "unexpected error"
                }
                runOnUiThread {
                    if (err != null) {
                        status.text = "Failed: $err"
                        status.setTextColor(Palette.ORANGE)
                    } else if (models.isEmpty()) {
                        status.text = "No models found for this key."
                        status.setTextColor(Palette.ORANGE)
                    } else {
                        status.text = "Found ${models.size} models. Pick one."
                        status.setTextColor(Palette.GREEN)
                        AlertDialog.Builder(this@AiSettingsActivity)
                            .setTitle("Choose model")
                            .setItems(models.toTypedArray()) { _, i ->
                                modelField.setText(models[i])
                                store.save(def, sw.isChecked, null, models[i], baseField?.text?.toString() ?: def.defaultBase)
                            }.show()
                    }
                }
            }.start()
        })
        card.addView(button("Remove saved key") {
            store.removeKey(def)
            sw.isChecked = false
            keyField.hint = "Paste API key here"
            status.text = "Key removed."
            status.setTextColor(Palette.SUBTEXT)
            Toast.makeText(this, "Key removed from this phone.", Toast.LENGTH_SHORT).show()
        })
        card.addView(status, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        return card
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(3), 0, dp(3))
    }

    private fun field(hintText: String, value: String, type: Int) = EditText(this).apply {
        hint = hintText
        setText(value)
        inputType = type
        setSingleLine(true)
        textSize = 14f
        setTextColor(Palette.TEXT)
        setHintTextColor(Palette.SUBTEXT)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), 0x5500E5FF)
        }
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
    }

    private fun button(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Palette.CYAN)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), Palette.CYAN)
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
    }
}
