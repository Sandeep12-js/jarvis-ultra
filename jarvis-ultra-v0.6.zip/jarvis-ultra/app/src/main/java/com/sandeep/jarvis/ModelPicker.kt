package com.sandeep.jarvis

/** Chooses real, currently-listed models from a provider's own live model list. */
object ModelPicker {
    private val bad = listOf(
        "whisper", "guard", "tts", "embed", "transcribe", "audio", "image", "live",
        "moderation", "orpheus", "playai", "allam", "imagen", "veo", "robotics", "computer-use", "aqa"
    )

    private fun prefs(def: ProviderDef, vision: Boolean): List<String> = when (def.id) {
        "gemini" -> listOf("3.8-flash", "3.6-flash", "3.5-flash-lite", "3.1-flash-lite", "flash")
        "groq" -> if (vision) listOf("qwen3.8", "llama-4-scout", "llama-4-maverick", "vision", "-vl")
        else listOf("gpt-oss-120b", "qwen3.8", "llama-3.3-70b", "llama-4", "gpt-oss-20b", "llama-3.1-8b")
        "openrouter" -> if (vision) listOf("-vl", "vision", "gemini", "llama-4", "gemma-3", "mistral-small")
        else listOf("llama-3.3-70b", "gpt-oss-120b", "qwen", "gemma", "deepseek", "mistral")
        else -> emptyList()
    }

    /** Best first. For images only models that look vision-capable are returned (except Gemini, all multimodal). */
    fun candidates(def: ProviderDef, ids: List<String>, vision: Boolean): List<String> {
        val p = prefs(def, vision)
        val ok = ids
            .filter { id -> bad.none { id.contains(it, ignoreCase = true) } }
            .filter { def.id != "gemini" || (it.startsWith("gemini-") && it.contains("flash")) }
            .filter { def.id != "openrouter" || it.endsWith(":free") }
        if (p.isEmpty()) return ok
        val scored = ArrayList<Pair<Int, String>>()
        for (id in ok) {
            val i = p.indexOfFirst { id.contains(it, ignoreCase = true) }
            if (i >= 0) scored.add(i to id)
            else if (!vision) scored.add(100 to id)
        }
        return scored
            .sortedWith(compareBy<Pair<Int, String>> { it.first }.thenByDescending { it.second })
            .map { it.second }
    }
}
