package com.sandeep.jarvis

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * JARVIS voice interface: glowing core, rotating tick ring, segmented ring, six flapping
 * "wings", wavy circular waveform and a circular equalizer. While listening it follows the
 * real microphone level; while speaking it pulses with a speech-like rhythm.
 */
class OrbView(context: Context) : View(context) {

    var state: AssistantState = AssistantState.READY
        set(value) {
            field = value
            invalidate()
        }

    /** Real microphone level 0..1 (set by the activity while listening). */
    @Volatile
    var level: Float = 0f

    private var smooth = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()
    private val path = Path()
    private val rnd = Random(5)
    private val pCount = 22
    private val pAngle = FloatArray(pCount) { rnd.nextFloat() * 6.2831855f }
    private val pRadius = FloatArray(pCount) { 0.45f + rnd.nextFloat() * 0.5f }
    private val pSize = FloatArray(pCount) { 0.6f + rnd.nextFloat() * 1.2f }
    private val pAlpha = IntArray(pCount) { 60 + rnd.nextInt(150) }

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    private fun a(color: Int, alpha: Int): Int =
        (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val b = min(w, h) / 2f * 0.97f
        val u = resources.displayMetrics.density
        val sec = (SystemClock.uptimeMillis() % 3_600_000L) / 1000f
        val deg2rad = 0.017453292f

        val accent: Int = when (state) {
            AssistantState.READY, AssistantState.LISTENING, AssistantState.SPEAKING -> Palette.CYAN
            AssistantState.SHARING -> 0xFF7FD4FF.toInt()
            else -> state.color
        }
        val wingColor: Int = when (state) {
            AssistantState.MUTED, AssistantState.ERROR, AssistantState.OFFLINE -> state.color
            AssistantState.THINKING -> Palette.PURPLE
            else -> Palette.BLUE
        }
        val dim = if (state == AssistantState.OFFLINE) 0.25f else 1f

        // Audio-like energy 0..1 and rotation speed
        val target: Float
        val speed: Float
        when (state) {
            AssistantState.LISTENING -> { target = max(level, 0.12f); speed = 1.6f }
            AssistantState.SPEAKING -> {
                target = 0.35f + 0.65f * abs(sin(sec * 8.3f) * sin(sec * 2.9f + 1f)); speed = 2.2f
            }
            AssistantState.THINKING -> { target = 0.4f + 0.2f * sin(sec * 4f); speed = 4.0f }
            AssistantState.READY -> { target = 0.12f; speed = 1.0f }
            AssistantState.SHARING -> { target = 0.25f; speed = 1.3f }
            AssistantState.ERROR -> { target = 0.5f + 0.4f * sin(sec * 9f); speed = 3.0f }
            AssistantState.STANDBY -> { target = 0.06f; speed = 0.5f }
            AssistantState.MUTED -> { target = 0.03f; speed = 0.3f }
            AssistantState.OFFLINE -> { target = 0f; speed = 0f }
        }
        smooth += (target - smooth) * 0.3f
        val lv = smooth.coerceIn(0f, 1f)

        // 1. Ambient glow
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx, cy, b * 1.08f,
            intArrayOf(a(accent, (120 * dim).toInt()), a(accent, (55 * dim).toInt()), a(accent, 0)),
            floatArrayOf(0.1f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, b * 1.08f, paint)
        paint.shader = null

        // 2. Outer tick ring (rotating) + thin circle
        ring.strokeWidth = u * 1.2f
        val rot0 = sec * 8.6f * speed * 0.3f
        for (i in 0 until 120) {
            val ang = (rot0 + i * 3f) * deg2rad
            val long = i % 5 == 0
            val ln = b * (if (long) 0.045f else 0.022f)
            ring.color = a(accent, ((if (long) 170 else 100) * dim).toInt())
            canvas.drawLine(
                cx + cos(ang) * b * 0.985f, cy + sin(ang) * b * 0.985f,
                cx + cos(ang) * (b * 0.985f - ln), cy + sin(ang) * (b * 0.985f - ln), ring
            )
        }
        ring.strokeWidth = u * 0.8f
        ring.color = a(accent, (70 * dim).toInt())
        canvas.drawCircle(cx, cy, b * 0.93f, ring)

        // 3. Segmented ring (24 dashes), rotating the other way
        ring.strokeWidth = u * 2.4f
        ring.color = a(accent, (210 * dim).toInt())
        var rr = b * 0.86f
        rect.set(cx - rr, cy - rr, cx + rr, cy + rr)
        val rot2 = -sec * 20f * speed * 0.35f
        for (k in 0 until 24) canvas.drawArc(rect, rot2 + k * 15f, 9f, false, ring)

        // 4. Six flapping wings
        for (k in 0 until 6) {
            val baseDeg = sec * 14f * speed * 0.5f + k * 60f
            val flap = 0.5f + 0.5f * sin(sec * (2f + 3f * lv) + k * 1.1f)
            val sweep = 24f + 30f * flap * (0.5f + lv)
            rr = b * (0.735f + 0.03f * lv * flap)
            rect.set(cx - rr, cy - rr, cx + rr, cy + rr)
            val start = baseDeg - sweep / 2f
            ring.strokeWidth = u * 8f
            ring.color = a(wingColor, (70 * dim).toInt())
            canvas.drawArc(rect, start, sweep, false, ring)
            ring.strokeWidth = u * 4.2f
            ring.color = a(wingColor, (235 * dim).toInt())
            canvas.drawArc(rect, start, sweep, false, ring)
            ring.strokeWidth = u * 1.5f
            ring.color = a(0xFFEBFCFF.toInt(), (200 * dim).toInt())
            canvas.drawArc(rect, start, sweep, false, ring)
        }

        // 5. Inner thin ring
        ring.strokeWidth = u * 1.1f
        ring.color = a(accent, (110 * dim).toInt())
        canvas.drawCircle(cx, cy, b * 0.63f, ring)

        // 6. Wavy circular waveform (3 lines)
        val ringR = floatArrayOf(0.52f, 0.505f, 0.54f)
        val ringA = intArrayOf(230, 140, 110)
        val ringW = floatArrayOf(2.2f, 1.6f, 1.4f)
        for (i in 0..2) {
            val amp = b * (0.012f + 0.05f * lv) * (if (i == 0) 1f else 0.8f)
            path.reset()
            for (j in 0..120) {
                val th = j / 120f * 6.2831855f
                val r = b * ringR[i] + amp * (
                    sin(3f * th + sec * 1.7f + i) +
                        0.6f * sin(5f * th - sec * 2.3f + i * 2f) +
                        0.4f * sin(8f * th + sec * 3.1f + i * 3f)
                    )
                val x = cx + r * cos(th)
                val y = cy + r * sin(th)
                if (j == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            ring.strokeWidth = u * ringW[i]
            ring.color = a(0xFFA0F5FF.toInt(), (ringA[i] * dim).toInt())
            canvas.drawPath(path, ring)
        }

        // 7. Circular equalizer spokes
        ring.strokeWidth = u * 1.6f
        ring.color = a(accent, (220 * dim).toInt())
        for (i in 0 until 72) {
            val ang = i * 5f * deg2rad
            val v = 0.5f + 0.5f * sin(sec * 5f + i * 0.8f) * sin(sec * 1.7f + i * 0.31f)
            val ln = b * (0.012f + 0.075f * lv * v)
            canvas.drawLine(
                cx + cos(ang) * b * 0.40f, cy + sin(ang) * b * 0.40f,
                cx + cos(ang) * (b * 0.40f + ln), cy + sin(ang) * (b * 0.40f + ln), ring
            )
        }

        // 8. Core
        val cr = b * 0.34f * (1f + 0.06f * lv)
        paint.shader = RadialGradient(
            cx, cy, cr,
            intArrayOf(a(Color.WHITE, (255 * dim).toInt()), a(accent, (190 * dim).toInt()), a(accent, 0)),
            floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, cr, paint)
        paint.shader = null
        paint.color = a(Color.WHITE, (255 * dim).toInt())
        canvas.drawCircle(cx, cy, b * 0.095f, paint)
        ring.strokeWidth = u * 2f
        ring.color = a(Color.WHITE, (210 * dim).toInt())
        canvas.drawCircle(cx, cy, b * 0.2f, ring)

        // 9. Sparkles
        for (i in 0 until pCount) {
            val ang = pAngle[i] + sec * 0.2f * (if (i % 2 == 0) 1f else -1f)
            val rad = b * pRadius[i]
            paint.color = a(Color.WHITE, (pAlpha[i] * dim).toInt())
            canvas.drawCircle(cx + cos(ang) * rad, cy + sin(ang) * rad, pSize[i] * u, paint)
        }
    }
}
