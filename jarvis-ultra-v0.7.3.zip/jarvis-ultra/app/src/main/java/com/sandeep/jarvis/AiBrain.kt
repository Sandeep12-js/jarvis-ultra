package com.sandeep.jarvis

import android.content.Context

class AiResult(val text: String?, val error: String?, val provider: String?)

/**
 * Picks the first working enabled provider (free-first order) and keeps a short in-memory chat.
 * If a model is gone or its free quota is used up, it automatically tries other real models
 * from the provider's own live model list.
 */
class AiBrain(ctx: Context) {
    private val store = AiStore(ctx.applicationContext)
    private val history = ArrayList<Pair<String, String>>()

    fun hasProvider(): Boolean = store.usableCount() > 0

    /** Used by the Settings "Save" button: finds a working free model automatically and reports it. */
    fun testProvider(def: ProviderDef): String {
        val cfg = store.config(def)
        if (cfg.key.isBlank()) return "Paste the key first."
        return try {
            val r = attempt(def, false, true) { c ->
                AiClient.chat(def, c, "Reply in at most six words.", emptyList(), "Say hello.")
            }
            "Working. Reply: " + r.take(60)
        } catch (e: AiException) {
            "Failed: " + e.message
        } catch (e: Exception) {
            "Failed: unexpected error"
        }
    }

    fun activeProviderId(): String? =
        Providers.all.firstOrNull { store.isUsable(it) }?.id

    fun activeProviderName(): String? =
        Providers.all.firstOrNull { store.isUsable(it) }?.title

    private fun systemPrompt(mode: AssistantMode): String {
        val base = "You are JARVIS, the personal AI voice assistant of the user. You were developed by Sandeep Sir; " +
            "if asked who developed you, answer exactly: Sandeep Sir. Address the user as Sir when natural. " +
            "Your replies are read aloud, so keep them short and natural (usually 1 to 3 sentences), with no markdown, " +
            "no lists and no emojis. Reply in the same language the user used (English, Hindi, Hinglish or Punjabi). " +
            "Be honest: you have no live internet access, and you can only see an image when the camera or screen is shared with you. " +
            "On this phone you can only open YouTube, Instagram and the browser, and run web searches. " +
            "Never claim you did something you did not do."
        val extra = when (mode) {
            AssistantMode.JARVIS -> " Be confident, respectful and helpful."
            AssistantMode.GF -> " Personality: warm, caring, friendly and supportive. Stay respectful and appropriate, and remain clearly an AI assistant."
            AssistantMode.PRO -> " Personality: technical and professional. Help with coding, research and troubleshooting. Explain clearly and precisely."
            AssistantMode.AGENT -> " Personality: task-oriented agent. For multi-step requests, state a short plan, but be honest that you can only perform the actions listed above."
        }
        return base + extra
    }

    private fun sourceNote(source: String): String = when (source) {
        "camera" -> " The user is showing you a live camera view. Answer about what is really visible. " +
            "If something looks broken or faulty, say what is likely wrong and give clear, safe, practical steps to fix it. " +
            "If the image is unclear, say so and ask them to show it closer."
        else -> " The user is sharing their phone screen with you. Answer about what is visible on it. " +
            "If they ask what to tap, name the button and where it is. If the question is unrelated to the screen, just answer normally."
    }

    /** Calls one provider; on a gone model / quota / busy error, tries up to 3 other real models. */
    private fun attempt(def: ProviderDef, vision: Boolean, persist: Boolean, call: (ProviderConfig) -> String): String {
        val cfg = store.config(def)
        try {
            return call(cfg)
        } catch (first: AiException) {
            val retryable = first.code == 400 || first.code == 404 || first.code == 429 || first.code >= 500
            if (!retryable) throw first
            val ids = try {
                AiClient.listModels(def, cfg)
            } catch (e: Exception) {
                throw first
            }
            val cands = ModelPicker.candidates(def, ids, vision).filter { it != cfg.model }.take(3)
            var last = first
            for (m in cands) {
                try {
                    val r = call(ProviderConfig(cfg.enabled, cfg.key, m, cfg.base))
                    if (persist) store.setModel(def, m)
                    return r
                } catch (e: AiException) {
                    last = e
                    if (e.code == 401 || e.code == 403) break
                }
            }
            throw last
        }
    }

    private fun run(mode: AssistantMode, text: String, jpeg: ByteArray?, source: String): AiResult {
        val vision = jpeg != null
        val system = systemPrompt(mode) + (if (vision) sourceNote(source) else "")
        val errors = ArrayList<String>()
        var tried = false
        for (def in Providers.all) {
            if (!store.isUsable(def)) continue
            tried = true
            try {
                val reply = attempt(def, vision, !vision) { cfg ->
                    if (jpeg != null) AiClient.chatImage(def, cfg, system, text, jpeg)
                    else AiClient.chat(def, cfg, system, history.takeLast(12), text)
                }
                history.add("user" to (if (vision) "[$source] $text" else text))
                history.add("assistant" to reply)
                while (history.size > 24) history.removeAt(0)
                return AiResult(reply, null, def.title)
            } catch (e: AiException) {
                errors.add(def.title + ": " + e.message)
            } catch (e: Exception) {
                errors.add(def.title + ": unexpected error")
            }
        }
        return if (!tried) AiResult(null, "No AI provider is enabled.", null)
        else AiResult(null, errors.joinToString("\n"), null)
    }

    @Synchronized
    fun ask(text: String, mode: AssistantMode): AiResult = run(mode, text, null, "")

    @Synchronized
    fun askWithImage(question: String, jpeg: ByteArray, mode: AssistantMode, source: String): AiResult =
        run(mode, question, jpeg, source)
}
