package com.sandeep.jarvis

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

/**
 * AI settings. The user only turns a service on and pastes a free key.
 * The working model is chosen automatically by AiBrain, so there is no model picker.
 */
class AiSettingsActivity : AppCompatActivity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private lateinit var store: AiStore
    private lateinit var brain: AiBrain

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        store = AiStore(this)
        brain = AiBrain(this)
        build()
    }

    private fun build() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(TextView(this).apply {
            text = "\u2190"
            textSize = 26f
            setTextColor(Palette.CYAN)
            gravity = Gravity.CENTER
            contentDescription = "Back"
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(56), dp(56)))
        bar.addView(TextView(this).apply {
            text = "AI"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
            setTextColor(Palette.CYAN)
        })
        root.addView(bar, LinearLayout.LayoutParams(MATCH, dp(56)))

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(32))
        }
        list.addView(TextView(this).apply {
            text = "Turn on the services you want, paste the free key once and tap Save. " +
                "JARVIS finds a working free model by itself. Keys stay encrypted on this phone."
            textSize = 13f
            setTextColor(Palette.SUBTEXT)
        })
        for (def in Providers.all) if (def.id != "custom") list.addView(providerCard(def))

        val scroll = ScrollView(this)
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val frame = FrameLayout(this).apply { setBackgroundColor(Palette.BG) }
        frame.addView(HudBackground(this), FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(root, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(frame)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
    }

    private fun providerCard(def: ProviderDef): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Palette.PANEL)
                setStroke(dp(1), 0x3300E5FF)
            }
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }
        }
        card.addView(TextView(this).apply {
            text = def.title
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Palette.CYAN)
        })
        card.addView(TextView(this).apply {
            text = def.costNote
            textSize = 12f
            setTextColor(Palette.YELLOW)
        })

        val status = TextView(this).apply {
            textSize = 13f
            setTextColor(Palette.TEXT)
            setPadding(0, dp(6), 0, 0)
            text = if (store.hasKey(def)) "Key saved." else "No key saved yet."
        }

        val sw = SwitchCompat(this).apply {
            text = "Use this service"
            isChecked = store.config(def).enabled
            setTextColor(Palette.TEXT)
        }
        card.addView(sw, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        val keyField = EditText(this).apply {
            hint = if (store.hasKey(def)) "Key saved (type a new one to replace)" else "Paste your free API key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
            textSize = 14f
            setTextColor(Palette.TEXT)
            setHintTextColor(Palette.SUBTEXT)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setStroke(dp(1), 0x5500E5FF)
            }
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
        }
        card.addView(keyField)
        card.addView(TextView(this).apply {
            text = def.keyHelp
            textSize = 12f
            setTextColor(Palette.SUBTEXT)
        })

        card.addView(button("Save") {
            val typed = keyField.text.toString().trim()
            if (typed.isNotEmpty()) store.save(def, sw.isChecked, typed, "", "")
            else store.save(def, sw.isChecked, null, "", "")
            if (!store.hasKey(def)) {
                status.text = "Paste the key first."
                status.setTextColor(Palette.ORANGE)
                return@button
            }
            status.text = "Checking the key and finding a free model..."
            status.setTextColor(Palette.SUBTEXT)
            Thread {
                val msg = brain.testProvider(def)
                val ok = msg.startsWith("Working")
                runOnUiThread {
                    status.text = msg
                    status.setTextColor(if (ok) Palette.GREEN else Palette.ORANGE)
                    keyField.setText("")
                    keyField.hint = "Key saved (type a new one to replace)"
                }
            }.start()
        })
        card.addView(button("Remove saved key") {
            store.removeKey(def)
            build()
        })
        card.addView(status)
        return card
    }

    private fun button(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Palette.CYAN)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), Palette.CYAN)
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
    }
}
