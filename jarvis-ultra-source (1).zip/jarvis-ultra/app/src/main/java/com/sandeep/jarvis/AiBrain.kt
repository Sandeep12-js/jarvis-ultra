package com.sandeep.jarvis

import android.content.Context

class AiResult(val text: String?, val error: String?, val provider: String?)

/** Picks the first working enabled provider (free-first order) and keeps a short in-memory chat. */
class AiBrain(ctx: Context) {
    private val store = AiStore(ctx.applicationContext)
    private val history = ArrayList<Pair<String, String>>()

    fun hasProvider(): Boolean = store.usableCount() > 0

    private fun systemPrompt(mode: AssistantMode): String {
        val base = "You are JARVIS, the personal AI voice assistant of the user. You were developed by Sandeep Sir; " +
            "if asked who developed you, answer exactly: Sandeep Sir. Address the user as Sir when natural. " +
            "Your replies are read aloud, so keep them short and natural (usually 1 to 3 sentences), with no markdown, " +
            "no lists and no emojis. Reply in the same language the user used (English, Hindi, Hinglish or Punjabi). " +
            "Be honest: you have no live internet access and cannot see the camera or screen. " +
            "On this phone you can only open YouTube, Instagram and the browser, and run web searches. " +
            "Never claim you did something you did not do."
        val extra = when (mode) {
            AssistantMode.JARVIS -> " Be confident, respectful and helpful."
            AssistantMode.GF -> " Personality: warm, caring, friendly and supportive. Stay respectful and appropriate, and remain clearly an AI assistant."
            AssistantMode.PRO -> " Personality: technical and professional. Help with coding, research and troubleshooting. Explain clearly and precisely."
            AssistantMode.AGENT -> " Personality: task-oriented agent. For multi-step requests, state a short plan, but be honest that you can only perform the actions listed above."
        }
        return base + extra
    }

    @Synchronized
    fun ask(text: String, mode: AssistantMode): AiResult {
        val system = systemPrompt(mode)
        val errors = ArrayList<String>()
        var tried = false
        for (def in Providers.all) {
            if (!store.isUsable(def)) continue
            tried = true
            try {
                val reply = AiClient.chat(def, store.config(def), system, history.takeLast(12), text)
                history.add("user" to text)
                history.add("assistant" to reply)
                while (history.size > 24) history.removeAt(0)
                return AiResult(reply, null, def.title)
            } catch (e: AiException) {
                errors.add(def.title + ": " + e.message)
            } catch (e: Exception) {
                errors.add(def.title + ": unexpected error")
            }
        }
        return if (!tried) AiResult(null, "No AI provider is enabled.", null)
        else AiResult(null, errors.joinToString("\n"), null)
    }
}
