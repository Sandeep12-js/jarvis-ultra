package com.sandeep.jarvis

import android.content.Context
import android.graphics.Color
import android.speech.tts.Voice

object Palette {
    val BG = Color.parseColor("#03060D")
    val CYAN = Color.parseColor("#00E5FF")
    val BLUE = Color.parseColor("#2979FF")
    val PURPLE = Color.parseColor("#B388FF")
    val GREEN = Color.parseColor("#00E676")
    val ORANGE = Color.parseColor("#FF6D00")
    val RED = Color.parseColor("#FF1744")
    val YELLOW = Color.parseColor("#FFD600")
    val GREY = Color.parseColor("#607D8B")
    val PANEL = Color.parseColor("#0D1626")
    val TEXT = Color.parseColor("#E6F7FF")
    val SUBTEXT = Color.parseColor("#8FA9BF")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

enum class AssistantState(val status: String, val orbLabel: String, val color: Int) {
    READY("JARVIS ONLINE", "SYSTEM READY", Palette.GREEN),
    LISTENING("LISTENING", "LISTENING...", Palette.CYAN),
    THINKING("THINKING", "THINKING...", Palette.PURPLE),
    SPEAKING("SPEAKING", "SPEAKING...", Palette.BLUE),
    STANDBY("STANDBY", "STANDBY", Palette.YELLOW),
    MUTED("MUTED", "MIC MUTED", Palette.RED),
    OFFLINE("OFFLINE", "POWER OFF", Palette.GREY),
    ERROR("ERROR", "ERROR", Palette.ORANGE),
    SHARING("SCREEN LIVE", "SCREEN SHARING", Palette.BLUE)
}

// Order matters: JARVIS, GF MODE, PRO MODE, AGENT MODE
enum class AssistantMode(
    val label: String,
    val blurb: String,
    val short: String,
    val glyph: String,
    val color: Int
) {
    JARVIS("JARVIS", "Full personal assistant", "JARVIS", "\u25C8", Color.parseColor("#2F9BFF")),
    GF("GF MODE", "Friendly, caring conversation", "GF", "\u2665", Color.parseColor("#E040FB")),
    PRO("PRO MODE", "Technical and professional", "PRO", "</>", Color.parseColor("#00E676")),
    AGENT("AGENT MODE", "Task-oriented agent", "AGENT", "\u2699", Color.parseColor("#FF9100"));

    companion object {
        fun fromName(n: String?): AssistantMode =
            values().firstOrNull { it.name == n } ?: JARVIS
    }
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)

    var language: String
        get() = sp.getString("language", "en-IN") ?: "en-IN"
        set(v) { sp.edit().putString("language", v).apply() }

    var voiceName: String?
        get() = sp.getString("voiceName", null)
        set(v) { sp.edit().putString("voiceName", v).apply() }

    var mode: String
        get() = sp.getString("mode", AssistantMode.JARVIS.name) ?: AssistantMode.JARVIS.name
        set(v) { sp.edit().putString("mode", v).apply() }

    var ttsEngine: String?
        get() = sp.getString("ttsEngine", null)
        set(v) { sp.edit().putString("ttsEngine", v).apply() }

    var powerOnDefault: Boolean
        get() = sp.getBoolean("powerOnDefault", true)
        set(v) { sp.edit().putBoolean("powerOnDefault", v).apply() }

    var micMutedDefault: Boolean
        get() = sp.getBoolean("micMutedDefault", false)
        set(v) { sp.edit().putBoolean("micMutedDefault", v).apply() }

    var useBackCamera: Boolean
        get() = sp.getBoolean("useBackCamera", true)
        set(v) { sp.edit().putBoolean("useBackCamera", v).apply() }

    var greeted: Boolean
        get() = sp.getBoolean("greeted", false)
        set(v) { sp.edit().putBoolean("greeted", v).apply() }
}

object Greetings {
    const val FIRST = "Hi, I am JARVIS. System online. I am your personal AI assistant. How can I help you, Sir?"
    const val POWER_ON = "System online, Sir."
}

object VoiceNames {
    /** Voices tried first when the user has not picked one: British male sounds closest to JARVIS. */
    val preferred = listOf("bm_lewis", "bm_george", "am_michael", "am_adam")

    fun code(raw: String): String = raw.substringAfterLast('#')

    fun friendly(raw: String): String {
        val c = code(raw)
        val m = Regex("^([ab])([fm])(?:_([a-z]+))?$").find(c) ?: return c
        val accent = if (m.groupValues[1] == "a") "US" else "UK"
        val gender = if (m.groupValues[2] == "f") "Female" else "Male"
        val name = m.groupValues[3].replaceFirstChar { it.uppercase() }.ifEmpty { "Classic" }
        return "$name \u2014 $accent $gender"
    }

    fun pick(voices: Collection<Voice>?, saved: String?): Voice? {
        if (voices == null) return null
        if (saved != null) voices.firstOrNull { it.name == saved }?.let { return it }
        for (p in preferred) {
            voices.firstOrNull { code(it.name) == p }?.let { return it }
        }
        return null
    }
}
