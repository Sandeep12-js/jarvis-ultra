package com.sandeep.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.drawerlayout.widget.DrawerLayout
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity(), VoiceEngine.Listener, CommandRouter.Host {

    private class Control(
        val root: LinearLayout,
        val frame: FrameLayout,
        val icon: ImageView,
        val caption: TextView
    )

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: Prefs
    private lateinit var voice: VoiceEngine
    private lateinit var brain: AiBrain
    private var aiToken = 0

    private lateinit var orb: OrbView
    private lateinit var miniOrb: OrbView
    private lateinit var previewView: PreviewView
    private lateinit var previewCard: FrameLayout
    private lateinit var statusView: TextView
    private lateinit var orbLabel: TextView
    private lateinit var hintView: TextView
    private lateinit var hintCard: ScrollView
    private lateinit var modeView: TextView
    private lateinit var drawer: DrawerLayout
    private lateinit var camControl: Control
    private lateinit var screenControl: Control
    private lateinit var micControl: Control
    private lateinit var powerControl: Control
    private lateinit var micLed: View
    private lateinit var tClock: TextView
    private lateinit var tBattery: TextView
    private lateinit var tNet: TextView
    private lateinit var tAi: TextView
    private val modeRows = LinkedHashMap<AssistantMode, TextView>()

    private val ui = Handler(Looper.getMainLooper())
    private val clockFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val ticker = object : Runnable {
        override fun run() {
            refreshTelemetry()
            ui.postDelayed(this, 1000)
        }
    }

    private var powerOn = true
    private var muted = false
    private var resumed = false
    private var voiceReady = false
    private var busy = AssistantState.READY
    private var errorMessage: String? = null
    private var hint: String? = null
    private var pendingAfter: (() -> Unit)? = null

    private var visionOn = false
    private var lensBack = true
    private var cameraProvider: ProcessCameraProvider? = null
    private var screenPending = false
    private var aiLabel = "NO KEY"

    override val currentMode: AssistantMode
        get() = AssistantMode.fromName(prefs.mode)

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                errorMessage = null
                hint = null
                startListeningIfAllowed()
            } else {
                hint = "Microphone permission denied. Enable it in phone Settings > Apps > JARVIS-ULTRA > Permissions."
            }
            updateUi()
        }

    private val camPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                openVision()
            } else {
                hint = "Camera permission denied. Enable it in phone Settings > Apps > JARVIS-ULTRA > Permissions."
                updateUi()
            }
        }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
            launchScreenCapture()
        }

    private val screenCapture =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val data = res.data
            if (res.resultCode == RESULT_OK && data != null) {
                screenPending = true
                voice.stopListening()
                voice.stopSpeaking()
                val i = Intent(this, ScreenAssistService::class.java)
                    .putExtra(ScreenAssistService.EXTRA_CODE, res.resultCode)
                    .putExtra(ScreenAssistService.EXTRA_DATA, data)
                try {
                    ContextCompat.startForegroundService(this, i)
                } catch (e: Exception) {
                    screenPending = false
                    hint = "Could not start screen sharing."
                }
            } else {
                hint = "Screen sharing was not allowed."
            }
            updateUi()
        }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = Prefs(this)
        brain = AiBrain(this)
        buildUi()
        voice = VoiceEngine(this, prefs, this)
        updateUi()
        voice.init { onVoiceReady() }
    }

    private fun onVoiceReady() {
        voiceReady = true
        if (!micGranted()) {
            hint = "JARVIS needs the microphone to hear you. Please allow it."
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
        if (powerOn) {
            if (!prefs.greeted) {
                prefs.greeted = true
                speakThen(Greetings.FIRST, null)
            } else {
                startListeningIfAllowed()
            }
        }
        updateUi()
    }

    override fun onStart() {
        super.onStart()
        ScreenAssistService.onStateChanged = { runOnUiThread { screenStateChanged() } }
    }

    override fun onStop() {
        ScreenAssistService.onStateChanged = null
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        aiLabel = brain.activeProviderName()?.uppercase(Locale.ROOT)?.take(10) ?: "NO KEY"
        ui.removeCallbacks(ticker)
        ui.post(ticker)
        if (screenPending && ScreenAssistService.running) screenPending = false
        if (voiceReady) {
            voice.refreshVoice()
            startListeningIfAllowed()
        }
        updateUi()
    }

    override fun onPause() {
        resumed = false
        pendingAfter = null
        aiToken++
        ui.removeCallbacks(ticker)
        closeVision()
        if (voiceReady) {
            voice.stopListening()
            voice.stopSpeaking()
        }
        if (busy == AssistantState.SPEAKING || busy == AssistantState.THINKING ||
            busy == AssistantState.LISTENING
        ) busy = AssistantState.READY
        super.onPause()
    }

    override fun onDestroy() {
        voice.destroy()
        super.onDestroy()
    }

    private fun sharing() = ScreenAssistService.running || screenPending

    private fun screenStateChanged() {
        if (ScreenAssistService.running) {
            screenPending = false
            hint = "Screen sharing is ON. JARVIS is listening in the background. Open any app and ask about your screen. Tap SCREEN to stop."
        } else {
            screenPending = false
            hint = "Screen sharing stopped."
            startListeningIfAllowed()
        }
        updateUi()
    }

    // ------------------------------------------------------------ UI building

    private fun glass(radius: Int, fill: Int, strokeColor: Int): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(radius).toFloat()
            setColor(fill)
            setStroke(dp(1), strokeColor)
        }

    private fun readout(label: String): Pair<LinearLayout, TextView> {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        box.addView(TextView(this).apply {
            text = label
            textSize = 8.5f
            letterSpacing = 0.25f
            setTextColor(Palette.SUBTEXT)
            gravity = Gravity.CENTER
        })
        val value = TextView(this).apply {
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setTextColor(Palette.CYAN)
            gravity = Gravity.CENTER
            text = "--"
        }
        box.addView(value)
        return box to value
    }

    private fun buildUi() {
        drawer = DrawerLayout(this)
        val content = FrameLayout(this).apply { setBackgroundColor(Palette.BG) }
        content.addView(HudBackground(this), FrameLayout.LayoutParams(MATCH, MATCH))
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        content.addView(main, FrameLayout.LayoutParams(MATCH, MATCH))

        // Header
        val header = FrameLayout(this)
        val menu = TextView(this).apply {
            text = "\u2630"
            textSize = 24f
            setTextColor(Palette.CYAN)
            gravity = Gravity.CENTER
            contentDescription = "Assistant modes"
            setOnClickListener { drawer.openDrawer(GravityCompat.START) }
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        titleBox.addView(TextView(this).apply {
            text = "JARVIS-ULTRA"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
            setTextColor(Palette.CYAN)
            gravity = Gravity.CENTER
            setShadowLayer(18f, 0f, 0f, Palette.CYAN)
        })
        titleBox.addView(TextView(this).apply {
            text = "PERSONAL AI ASSISTANT"
            textSize = 9.5f
            letterSpacing = 0.35f
            setTextColor(Palette.SUBTEXT)
            gravity = Gravity.CENTER
        })
        val gear = TextView(this).apply {
            text = "\u2699"
            textSize = 24f
            setTextColor(Palette.SUBTEXT)
            gravity = Gravity.CENTER
            contentDescription = "Settings"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        header.addView(menu, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.START or Gravity.CENTER_VERTICAL))
        header.addView(titleBox, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        header.addView(gear, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END or Gravity.CENTER_VERTICAL))
        main.addView(header, LinearLayout.LayoutParams(MATCH, dp(64)))

        // Status capsule + mode
        statusView = TextView(this).apply {
            textSize = 12.5f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.16f
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(5), dp(18), dp(5))
        }
        main.addView(statusView, LinearLayout.LayoutParams(WRAP, WRAP).apply {
            topMargin = dp(2)
            gravity = Gravity.CENTER_HORIZONTAL
        })
        modeView = TextView(this).apply {
            textSize = 10.5f
            setTextColor(Palette.SUBTEXT)
            letterSpacing = 0.14f
            gravity = Gravity.CENTER
        }
        main.addView(modeView, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })

        // Telemetry readouts (all real values)
        val (clockBox, clockValue) = readout("TIME")
        val (batBox, batValue) = readout("POWER")
        val (netBox, netValue) = readout("NETWORK")
        val (aiBox, aiValue) = readout("AI LINK")
        tClock = clockValue; tBattery = batValue; tNet = netValue; tAi = aiValue
        val telemetry = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = glass(12, 0x22091526, 0x3300E5FF)
        }
        for (b in listOf(clockBox, batBox, netBox, aiBox)) {
            telemetry.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        main.addView(telemetry, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            leftMargin = dp(20)
            rightMargin = dp(20)
            topMargin = dp(8)
        })

        main.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        // Stage: orb, or the live camera view when vision is on
        val stage = FrameLayout(this)
        orb = OrbView(this)
        stage.addView(orb, FrameLayout.LayoutParams(dp(250), dp(250), Gravity.CENTER))

        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        previewCard = FrameLayout(this).apply {
            visibility = View.GONE
            background = glass(18, 0xFF050B14.toInt(), 0x9900E5FF.toInt())
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(18).toFloat())
                }
            }
            setOnClickListener { askFrame("What do you see? Explain briefly.") }
        }
        previewCard.addView(previewView, FrameLayout.LayoutParams(MATCH, MATCH))
        previewCard.addView(TextView(this).apply {
            text = "\u25CF VISION LIVE"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.12f
            setTextColor(Palette.GREEN)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = glass(10, 0x99000000.toInt(), Palette.GREEN)
        }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).apply {
            topMargin = dp(10); leftMargin = dp(10)
        })
        miniOrb = OrbView(this)
        previewCard.addView(miniOrb, FrameLayout.LayoutParams(dp(70), dp(70), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(4); rightMargin = dp(4)
        })
        previewCard.addView(TextView(this).apply {
            text = "Tap to ask \u2022 or just speak"
            textSize = 11f
            setTextColor(Palette.TEXT)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = glass(10, 0x99000000.toInt(), 0x3300E5FF)
        }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).apply {
            bottomMargin = dp(10); leftMargin = dp(10)
        })
        previewCard.addView(TextView(this).apply {
            text = "\u27F2"
            textSize = 22f
            setTextColor(Palette.CYAN)
            gravity = Gravity.CENTER
            contentDescription = "Switch camera"
            background = glass(22, 0x99000000.toInt(), 0x6600E5FF)
            setOnClickListener {
                lensBack = !lensBack
                bindCamera()
            }
        }, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM or Gravity.END).apply {
            bottomMargin = dp(8); rightMargin = dp(8)
        })
        stage.addView(previewCard, FrameLayout.LayoutParams(MATCH, MATCH).apply {
            leftMargin = dp(16); rightMargin = dp(16); topMargin = dp(4); bottomMargin = dp(4)
        })
        main.addView(stage, LinearLayout.LayoutParams(MATCH, dp(290)))

        orbLabel = TextView(this).apply {
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.22f
            gravity = Gravity.CENTER
        }
        main.addView(orbLabel, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })

        // Conversation card
        hintView = TextView(this).apply {
            textSize = 13.5f
            setTextColor(Palette.TEXT)
            setLineSpacing(0f, 1.1f)
        }
        hintCard = ScrollView(this).apply {
            background = glass(16, 0x33091526, 0x4400E5FF)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            addView(hintView)
        }
        main.addView(hintCard, LinearLayout.LayoutParams(MATCH, dp(100)).apply {
            leftMargin = dp(20)
            rightMargin = dp(20)
            topMargin = dp(8)
        })

        main.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        // Exactly four bottom controls, inside a glass dock
        camControl = control(R.drawable.ic_camera, "CAMERA", Palette.CYAN) { onCameraTapped() }
        screenControl = control(R.drawable.ic_screen, "SCREEN", Palette.BLUE) { onScreenTapped() }
        micControl = control(R.drawable.ic_mic, "MIC", Palette.CYAN) { onMicTapped() }
        powerControl = control(R.drawable.ic_power, "POWER", Palette.GREEN) { onPowerTapped() }

        micLed = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Palette.YELLOW) }
        }
        micControl.frame.addView(
            micLed,
            FrameLayout.LayoutParams(dp(14), dp(14), Gravity.TOP or Gravity.END)
        )

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = glass(30, 0x66091526, 0x4400E5FF)
            setPadding(dp(6), dp(12), dp(6), dp(8))
        }
        for (c in listOf(camControl, screenControl, micControl, powerControl)) {
            dock.addView(c.root, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        main.addView(dock, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            leftMargin = dp(14)
            rightMargin = dp(14)
            topMargin = dp(8)
        })

        // Side panel with the four modes, in order
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Palette.PANEL)
            setPadding(dp(16), dp(64), dp(16), dp(16))
        }
        panel.addView(TextView(this).apply {
            text = "ASSISTANT MODES"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.18f
            setTextColor(Palette.CYAN)
            setPadding(0, 0, 0, dp(16))
        })
        val glyphs = mapOf(
            AssistantMode.JARVIS to "\u25C9",
            AssistantMode.GF to "\u2665",
            AssistantMode.PRO to "</>",
            AssistantMode.AGENT to "\u25B6"
        )
        for (m in AssistantMode.values()) {
            val rowView = TextView(this).apply {
                text = (glyphs[m] ?: "") + "  " + m.label + "\n" + m.blurb
                textSize = 15f
                setTextColor(Palette.TEXT)
                setPadding(dp(14), dp(14), dp(14), dp(14))
                setOnClickListener {
                    drawer.closeDrawer(GravityCompat.START)
                    switchMode(m)
                    speakThen("${m.label} selected, Sir.", null)
                }
            }
            modeRows[m] = rowView
            panel.addView(rowView, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) })
        }

        drawer.addView(content, DrawerLayout.LayoutParams(MATCH, MATCH))
        drawer.addView(panel, DrawerLayout.LayoutParams(dp(270), MATCH, Gravity.START))
        setContentView(drawer)

        ViewCompat.setOnApplyWindowInsetsListener(main) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom + dp(10))
            insets
        }
    }

    private fun control(iconRes: Int, caption: String, accent: Int, onClick: () -> Unit): Control {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val frame = FrameLayout(this)
        val icon = ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(accent)
            setPadding(dp(18), dp(18), dp(18), dp(18))
            contentDescription = caption
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x2200E5FF)
                setStroke(dp(2), accent)
            }
            setOnClickListener { onClick() }
        }
        frame.addView(icon, FrameLayout.LayoutParams(dp(62), dp(62), Gravity.CENTER))
        col.addView(frame, LinearLayout.LayoutParams(dp(72), dp(72)))
        val cap = TextView(this).apply {
            text = caption
            textSize = 10.5f
            letterSpacing = 0.14f
            setTextColor(Palette.SUBTEXT)
            gravity = Gravity.CENTER
        }
        col.addView(cap, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(4) })
        return Control(col, frame, icon, cap)
    }

    // ------------------------------------------------------------ telemetry (real device values)

    private fun refreshTelemetry() {
        tClock.text = clockFmt.format(Date())
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        tBattery.text = if (level >= 0 && scale > 0) "${level * 100 / scale}%" else "--"
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = try {
            cm.getNetworkCapabilities(cm.activeNetwork)
        } catch (e: Exception) {
            null
        }
        tNet.text = when {
            caps == null -> "OFFLINE"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WI-FI"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "MOBILE"
            else -> "ONLINE"
        }
        tAi.text = aiLabel
        tAi.setTextColor(if (aiLabel == "NO KEY") Palette.ORANGE else Palette.GREEN)
    }

    // ------------------------------------------------------------ state / UI refresh

    private fun micGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun camGranted() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

    private fun effectiveState(): AssistantState = when {
        !powerOn -> AssistantState.OFFLINE
        errorMessage != null -> AssistantState.ERROR
        sharing() -> AssistantState.SHARING
        busy == AssistantState.SPEAKING || busy == AssistantState.THINKING -> busy
        muted -> AssistantState.MUTED
        !micGranted() -> AssistantState.STANDBY
        else -> busy
    }

    private fun styled(text: String): CharSequence {
        val sb = SpannableStringBuilder()
        val lines = text.split("\n")
        for ((idx, line) in lines.withIndex()) {
            if (idx > 0) sb.append("\n")
            val start = sb.length
            sb.append(line)
            val tag = when {
                line.startsWith("You:") -> "You:" to Palette.CYAN
                line.startsWith("JARVIS:") -> "JARVIS:" to Palette.PURPLE
                line.startsWith("AI error:") -> "AI error:" to Palette.ORANGE
                else -> null
            }
            if (tag != null) {
                val end = start + tag.first.length
                sb.setSpan(ForegroundColorSpan(tag.second), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(StyleSpan(Typeface.BOLD), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        return sb
    }

    private fun updateUi() {
        val st = effectiveState()
        orb.state = st
        miniOrb.state = st
        statusView.text = "\u25CF " + st.status
        statusView.setTextColor(st.color)
        statusView.background = GradientDrawable().apply {
            cornerRadius = dp(22).toFloat()
            setColor((st.color and 0x00FFFFFF) or 0x22000000)
            setStroke(dp(1), st.color)
        }
        orbLabel.text = st.orbLabel
        orbLabel.setTextColor(st.color)
        val shown = errorMessage ?: hint ?: ""
        if (errorMessage != null) {
            hintView.text = shown
            hintView.setTextColor(Palette.ORANGE)
        } else {
            hintView.text = styled(shown)
            hintView.setTextColor(Palette.TEXT)
        }
        hintCard.visibility = if (shown.isEmpty()) View.INVISIBLE else View.VISIBLE
        hintCard.post { hintCard.fullScroll(View.FOCUS_DOWN) }
        modeView.text = "MODE  \u2022  " + currentMode.label

        val led = when {
            !powerOn -> Palette.GREY
            muted -> Palette.RED
            st == AssistantState.LISTENING -> Palette.GREEN
            else -> Palette.YELLOW
        }
        (micLed.background as GradientDrawable).setColor(led)
        micControl.icon.setColorFilter(if (muted) Palette.RED else Palette.CYAN)
        powerControl.icon.setColorFilter(if (powerOn) Palette.GREEN else Palette.GREY)
        camControl.icon.setColorFilter(if (visionOn) Palette.GREEN else Palette.CYAN)
        camControl.caption.text = if (visionOn) "LIVE" else "CAMERA"
        screenControl.icon.setColorFilter(if (sharing()) Palette.GREEN else Palette.BLUE)
        screenControl.caption.text = if (sharing()) "SHARING" else "SCREEN"

        for ((m, v) in modeRows) {
            val sel = m == currentMode
            v.background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(if (sel) 0x3300E5FF else 0x11FFFFFF)
                setStroke(dp(1), if (sel) Palette.CYAN else 0x22FFFFFF)
            }
        }
    }

    // ------------------------------------------------------------ user actions

    private fun onMicTapped() {
        if (!powerOn) {
            hint = "JARVIS is powered off. Tap the power button first."
            updateUi()
            return
        }
        if (sharing()) {
            hint = "While screen sharing is on, JARVIS listens in the background. Tap SCREEN to stop sharing first."
            updateUi()
            return
        }
        if (errorMessage != null) {            // retry after a failure
            errorMessage = null
            hint = null
            if (!micGranted()) micPermission.launch(Manifest.permission.RECORD_AUDIO)
            else startListeningIfAllowed()
            updateUi()
            return
        }
        muted = !muted
        if (muted) {
            voice.stopListening()
            hint = "Microphone muted. JARVIS cannot hear you."
        } else {
            hint = null
            if (!micGranted()) micPermission.launch(Manifest.permission.RECORD_AUDIO)
            else startListeningIfAllowed()
        }
        updateUi()
    }

    private fun onPowerTapped() {
        if (powerOn) powerOff() else powerOnNow()
    }

    private fun powerOnNow() {
        powerOn = true
        errorMessage = null
        hint = null
        speakThen(Greetings.POWER_ON, null)
        updateUi()
    }

    private fun startListeningIfAllowed() {
        if (!resumed || !voiceReady || !powerOn || muted || errorMessage != null) return
        if (sharing()) return
        if (busy == AssistantState.SPEAKING || busy == AssistantState.THINKING) return
        if (!micGranted()) return
        voice.startListening()
    }

    private fun speakThen(text: String, after: (() -> Unit)?) {
        pendingAfter = after
        hint = (hint?.takeIf { it.startsWith("You:") }?.plus("\n") ?: "") + "JARVIS: " + text
        busy = AssistantState.THINKING
        updateUi()
        voice.speak(text)
    }

    // ------------------------------------------------------------ live camera vision

    private fun onCameraTapped() {
        if (visionOn) {
            closeVision()
            hint = "Camera off."
            updateUi()
            return
        }
        if (!powerOn) {
            hint = "JARVIS is powered off. Tap the power button first."
            updateUi()
            return
        }
        if (sharing()) {
            hint = "Stop screen sharing first. Camera and screen sharing cannot run together."
            updateUi()
            return
        }
        if (!brain.hasProvider()) {
            hint = "Camera vision needs an AI provider that understands images, for example Google Gemini. " +
                "Add a key in Settings > AI Models & Networks."
            updateUi()
            return
        }
        if (!camGranted()) {
            camPermission.launch(Manifest.permission.CAMERA)
            return
        }
        openVision()
    }

    private fun openVision() {
        visionOn = true
        orb.visibility = View.GONE
        previewCard.visibility = View.VISIBLE
        bindCamera()
        speakThen("Camera is on, Sir. Show me something and ask.", null)
    }

    private fun closeVision() {
        if (!visionOn) return
        visionOn = false
        try {
            cameraProvider?.unbindAll()
        } catch (e: Exception) {
            // already released
        }
        previewCard.visibility = View.GONE
        orb.visibility = View.VISIBLE
        updateUi()
    }

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener(Runnable {
            try {
                val provider = future.get()
                cameraProvider = provider
                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(previewView.surfaceProvider)
                val selector =
                    if (lensBack) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, preview)
            } catch (e: Exception) {
                hint = "Could not start the camera."
                closeVision()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun askFrame(question: String) {
        if (!visionOn) return
        if (busy == AssistantState.THINKING || busy == AssistantState.SPEAKING) return
        val bmp = previewView.bitmap
        if (bmp == null) {
            speakThen("The camera is not ready yet, Sir.", null)
            return
        }
        sendImage(bmp, question, "camera")
    }

    private fun sendImage(bmp: Bitmap, question: String, source: String) {
        val token = ++aiToken
        busy = AssistantState.THINKING
        hint = "You: $question"
        updateUi()
        val mode = currentMode
        Thread {
            val longest = maxOf(bmp.width, bmp.height)
            val send = if (longest > 1280) {
                val s = 1280f / longest
                Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
            } else bmp
            val bos = ByteArrayOutputStream()
            send.compress(Bitmap.CompressFormat.JPEG, 80, bos)
            val r = brain.askWithImage(question, bos.toByteArray(), mode, source)
            runOnUiThread { deliverAi(token, r) }
        }.start()
    }

    // ------------------------------------------------------------ screen sharing

    private fun onScreenTapped() {
        if (sharing()) {
            stopService(Intent(this, ScreenAssistService::class.java))
            screenPending = false
            hint = "Screen sharing stopped."
            updateUi()
            startListeningIfAllowed()
            return
        }
        if (!powerOn) {
            hint = "JARVIS is powered off. Tap the power button first."
            updateUi()
            return
        }
        if (!brain.hasProvider()) {
            hint = "Screen understanding needs an AI provider that understands images, for example Google Gemini. " +
                "Add a key in Settings > AI Models & Networks."
            updateUi()
            return
        }
        if (!micGranted()) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        closeVision()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            launchScreenCapture()
        }
    }

    private fun launchScreenCapture() {
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            screenCapture.launch(mpm.createScreenCaptureIntent())
        } catch (e: Exception) {
            hint = "Could not open Android's screen-sharing permission."
            updateUi()
        }
    }

    // ------------------------------------------------------------ AI

    private fun deliverAi(token: Int, r: AiResult) {
        if (token != aiToken || !powerOn || isFinishing) return
        val answer = r.text
        if (answer != null) {
            speakThen(forSpeech(answer), null)
        } else {
            speakThen("Sorry Sir, I could not get an answer from the AI.", null)
            hint = (hint ?: "") + "\nAI error: " + (r.error ?: "unknown")
            updateUi()
        }
    }

    private fun askAi(text: String) {
        if (!brain.hasProvider()) {
            speakThen(
                "AI is not connected yet, Sir. Open Settings, then AI Models and Networks, and add a free Gemini key.",
                null
            )
            return
        }
        val token = ++aiToken
        busy = AssistantState.THINKING
        hint = "You: $text"
        updateUi()
        val mode = currentMode
        Thread {
            val r = brain.ask(text, mode)
            runOnUiThread { deliverAi(token, r) }
        }.start()
    }

    private fun forSpeech(t: String): String =
        t.replace(Regex("[*_`#>]"), "").replace(Regex("\\s+"), " ").trim().take(900)

    // ------------------------------------------------------------ VoiceEngine.Listener

    override fun onHeard(text: String) {
        busy = AssistantState.THINKING
        hint = "You: $text"
        updateUi()
        val lower = text.lowercase(Locale.ROOT)
        if (visionOn) {
            if (Regex("close camera|stop camera|camera off|turn off camera|camera band").containsMatchIn(lower)) {
                closeVision()
                speakThen("Camera off, Sir.", null)
                return
            }
            val camPhrase = Regex("in front of me|look at this|read this text|open camera|take a (photo|picture)")
                .containsMatchIn(lower)
            val local = CommandRouter.handle(text, this)
            if (local != null && !camPhrase) {
                speakThen(local.text, local.after)
            } else {
                busy = AssistantState.READY
                askFrame(text)
            }
            return
        }
        val reply = CommandRouter.handle(text, this)
        if (reply != null) {
            speakThen(reply.text, reply.after)
        } else {
            askAi(text)
        }
    }

    override fun onListeningStarted() {
        if (busy != AssistantState.SPEAKING && busy != AssistantState.THINKING) {
            busy = AssistantState.LISTENING
            updateUi()
        }
    }

    override fun onVoiceError(message: String, fatal: Boolean) {
        if (fatal) errorMessage = message else hint = message
        updateUi()
    }

    override fun onSpeakStart() {
        busy = AssistantState.SPEAKING
        updateUi()
    }

    override fun onSpeakDone() {
        busy = AssistantState.READY
        val after = pendingAfter
        pendingAfter = null
        after?.invoke()
        startListeningIfAllowed()
        updateUi()
    }

    // ------------------------------------------------------------ CommandRouter.Host

    override fun switchMode(mode: AssistantMode) {
        prefs.mode = mode.name
        updateUi()
    }

    override fun muteMic() {
        muted = true
        voice.stopListening()
        updateUi()
    }

    override fun powerOff() {
        powerOn = false
        aiToken++
        pendingAfter = null
        closeVision()
        if (sharing()) {
            stopService(Intent(this, ScreenAssistService::class.java))
            screenPending = false
        }
        voice.stopListening()
        voice.stopSpeaking()
        busy = AssistantState.READY
        errorMessage = null
        hint = "JARVIS is powered off. Listening has stopped."
        updateUi()
    }

    override fun openUrl(url: String): Boolean = try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    override fun openCamera() {
        if (!visionOn) onCameraTapped()
    }

    override fun openScreenShare() {
        if (!sharing()) onScreenTapped()
    }

    override fun say(text: String) = speakThen(text, null)
}
